---
name: code-video-starter
description: Make a short vertical video (Reel, TikTok or Short) from a script with code instead of a paid video app. A robot presenter talks the script with a free local voice while animated cards and captions play, then the free HyperFrames tool renders an MP4. Use when the user wants to turn a script into an explainer video, make a new episode from this template, or change a scene by describing it.
---

# Code video starter

This folder is a working template. A video is a JSON spec: the lines to say, the cards to show and the comment-for-the-link ending. The scripts turn it into a web page, a voice track and an MP4.

## Make a new video

1. Copy `specs/01_example.json` to `specs/NN_slug.json` and change it with the user. Keep each line short and spoken. Write numbers in words in `say` and in digits in `show`.
2. For each card, pick a type from `README.md` and set when each item appears with `at`: a word from the script, seconds after the card lands, or `"+0.3"` after the previous item.
3. Run `python3 build.py specs/NN_slug.json`, then `python3 qa_all.py qa NN` and look at the screenshots. Fix any text the QA report says spills out of a card.
4. Render with `./render.sh ../build/NN_slug`, then `python3 post.py out NN` for the final MP4, cover and caption.

## Changing things by description

When the user asks for a change in plain English ("make the robot wave", "add a card about pricing"), edit the spec, or `robot.svg`, `reel.css` and `runtime.js`, rebuild, and show the new screenshots before rendering.

## Rules

- Keep the video under 30 seconds and the file under 10 MB.
- Use made-up demo data on screen, never real customers or private details.
- Keep text away from the bottom right corner, where Instagram and TikTok put their buttons.
