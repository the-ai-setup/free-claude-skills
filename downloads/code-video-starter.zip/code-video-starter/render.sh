#!/bin/bash
# usage: render.sh build/01_human [build/02_skills ...]   renders each project to master.mp4 (about 100 s each on 2 cores)
export HYPERFRAMES_BROWSER_PATH=${HYPERFRAMES_BROWSER_PATH:-/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell}
for d in "$@"; do
  ( cd "$d" && rm -rf master.mp4 work-* .master.hf-transaction-* && s=$(date +%s) && \
    timeout 400 npx -y hyperframes@0.8.216 render . -o master.mp4 --quality looks --no-low-memory-mode --workers 2 > render.log 2>&1; \
    echo "$(basename $d): exit $? in $(( $(date +%s) - s ))s, $(du -h master.mp4 2>/dev/null | cut -f1)" )
done
