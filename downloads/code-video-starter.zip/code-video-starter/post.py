#!/usr/bin/env python3
"""After render: final MP4 (under 9.8 MB, faststart), cover JPG and caption TXT for each reel.

usage: python3 post.py <out_dir> [NN ...]
"""
import json
import os
import subprocess
import sys

ENGINE = os.path.dirname(os.path.abspath(__file__))
BUILD = os.path.join(ENGINE, '..', 'build')
LIMIT = 9.6 * 1024 * 1024
TAGS = ['#claudeai', '#claude', '#aitools', '#aiforbeginners', '#productivity']
FOLLOW = "New skills each week. Follow so you don't miss one."


def final_mp4(src, dst, dur):
    if os.path.getsize(src) <= LIMIT:
        subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', src, '-c', 'copy', '-movflags', '+faststart', dst], check=True)
        return 'copied'
    kbps = int((9.3 * 8 * 1024) / dur - 128)
    import tempfile, shutil
    logdir = tempfile.mkdtemp()
    for p in (1, 2):
        args = ['ffmpeg', '-v', 'error', '-y', '-i', src, '-c:v', 'libx264', '-preset', 'slow', '-b:v', f'{kbps}k',
                '-pix_fmt', 'yuv420p', '-pass', str(p), '-passlogfile', os.path.join(logdir, 'pass')]
        args += (['-an', '-f', 'mp4', os.devnull] if p == 1 else ['-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', dst])
        subprocess.run(args, check=True)
    shutil.rmtree(logdir, ignore_errors=True)
    return f're-encoded at {kbps}k'


def caption(spec):
    cta = spec['lines'][spec['cta']['line']]['say']
    lines = [f"{spec['headline'][0]} {spec['headline'][1]}", '', *spec['caption'], '', cta, FOLLOW, '', ' '.join(TAGS)]
    return '\n'.join(lines) + '\n'


def main():
    out = os.path.abspath(sys.argv[1])
    only = sys.argv[2:]
    os.makedirs(out, exist_ok=True)
    rows = []
    for name in sorted(os.listdir(BUILD)):
        if only and name[:2] not in only:
            continue
        d = os.path.join(BUILD, name)
        if not os.path.exists(os.path.join(d, 'master.mp4')):
            continue
        meta = json.load(open(os.path.join(d, 'meta.json')))
        spec = json.load(open(os.path.join(ENGINE, 'specs', name + '.json')))
        how = final_mp4(os.path.join(d, 'master.mp4'), os.path.join(out, name + '.mp4'), meta['total'])
        cover_t = spec.get('cover_t', meta['cover_t'])
        subprocess.run(['node', os.path.join(ENGINE, 'cover.js'), d, os.path.join(out, f'{name[:2]}_cover.jpg'), str(cover_t)],
                       check=True, capture_output=True, cwd=ENGINE)
        open(os.path.join(out, f'{name[:2]}_caption.txt'), 'w').write(caption(spec))
        size = os.path.getsize(os.path.join(out, name + '.mp4')) / 1024 / 1024
        rows.append((name, meta['total'], round(size, 2), how))
        print(f'{name}: {meta["total"]}s, {size:.2f} MB ({how}), cover at {cover_t}s')
    return rows


if __name__ == '__main__':
    main()
