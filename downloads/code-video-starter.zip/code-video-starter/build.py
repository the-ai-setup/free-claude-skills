#!/usr/bin/env python3
"""Claude page reel builder.

spec JSON -> build/NN_slug/ (index.html, audio/mix.wav, fonts, gsap) ready for:
  HYPERFRAMES_BROWSER_PATH=... npx -y hyperframes@0.8.216 render build/NN_slug -o master.mp4 --quality looks

Usage: python3 build.py specs/01_night.json [--out ../build]
Voice: Kokoro (local, free), British English. Music and sound effects are generated here (no licences needed).
"""
import hashlib
import html as H
import json
import math
import os
import re
import shutil
import subprocess
import sys

import numpy as np
import soundfile as sf

ENGINE = os.path.dirname(os.path.abspath(__file__))
SR = 24000
FPS = 30
LEAD = 0.18      # silence before the first word
HOLD = 1.9       # seconds the CTA stays up after the last word
PUN = ',;:.?!'


def esc(s):
    return H.escape(str(s), quote=True)


def norm(w):
    return re.sub(r"[^a-z0-9£%]", "", w.lower().replace("’", "").replace("'", ""))


# ---------------------------------------------------------------- voice
def find_model():
    for c in [os.environ.get('KOKORO_DIR', ''), '/root/.cache/hyperframes/tts',
              os.path.expanduser('~/.cache/hyperframes/tts')]:
        m = os.path.join(c, 'models', 'kokoro-v1.0.onnx')
        v = os.path.join(c, 'voices', 'voices-v1.0.bin')
        if c and os.path.exists(m) and os.path.exists(v):
            return m, v
    raise SystemExit('Kokoro model not found. Run once: npx -y hyperframes@0.8.216 tts "hello" -o /tmp/warm.wav '
                     '(it downloads the model), or set KOKORO_DIR.')


_K = None


def trim(s, thr=0.012, pad=0.04):
    idx = np.where(np.abs(s) > thr)[0]
    if not len(idx):
        return s
    return s[max(0, idx[0] - int(pad * SR)):min(len(s), idx[-1] + int(pad * SR))]


def tts(text, voice, speed, cache):
    global _K
    os.makedirs(cache, exist_ok=True)
    key = hashlib.sha1(f'{voice}|{speed}|{text}'.encode()).hexdigest()[:16]
    p = os.path.join(cache, key + '.wav')
    if os.path.exists(p):
        a, _ = sf.read(p, dtype='float32')
        return a
    if _K is None:
        import kokoro_onnx
        m, v = find_model()
        _K = kokoro_onnx.Kokoro(m, v)
    s, sr = _K.create(text, voice=voice, speed=speed, lang='en-gb' if str(voice).startswith('b') else 'en-us')
    assert sr == SR, sr
    s = trim(np.asarray(s, dtype='float32'))
    sf.write(p, s, SR)
    return s


def word_times(say, a):
    """Start time (s, relative to the line) of every word, using the line's own pauses for clause boundaries."""
    toks = say.split()
    n = len(toks)
    dur = len(a) / SR
    hop, win = int(0.01 * SR), int(0.03 * SR)
    fr = np.array([np.sqrt(np.mean(a[i:i + win] ** 2)) for i in range(0, max(1, len(a) - win), hop)])
    thr = max(0.01, 0.10 * np.percentile(fr, 95))
    v = fr > thr
    pauses, i, m = [], 0, len(v)
    while i < m:
        if not v[i]:
            j = i
            while j < m and not v[j]:
                j += 1
            if i > 0 and j < m and (j - i) >= 6:
                pauses.append((i * hop / SR, j * hop / SR))
            i = j
        else:
            i += 1
    vi = np.where(v)[0]
    s0 = vi[0] * hop / SR if len(vi) else 0.0
    s1 = (vi[-1] * hop + win) / SR if len(vi) else dur
    W = [max(2, len(norm(t))) + 1.2 for t in toks]
    out = [0.0] * n
    bidx = [k for k, t in enumerate(toks[:-1]) if t[-1] in PUN]
    if bidx and len(pauses) >= len(bidx):
        ch = sorted(sorted(pauses, key=lambda p: p[1] - p[0], reverse=True)[:len(bidx)])
        bounds = [-1] + bidx + [n - 1]
        for j in range(len(bounds) - 1):
            ws = list(range(bounds[j] + 1, bounds[j + 1] + 1))
            ts = s0 if j == 0 else ch[j - 1][1]
            te = s1 if j == len(bounds) - 2 else ch[j][0]
            tot, c = sum(W[k] for k in ws), 0.0
            for k in ws:
                out[k] = ts + (c / tot) * (te - ts)
                c += W[k]
    else:
        W2 = [W[k] + (3.0 if toks[k][-1] in PUN and k < n - 1 else 0) for k in range(n)]
        tot, c = sum(W2), 0.0
        for k in range(n):
            out[k] = s0 + (c / tot) * (s1 - s0)
            c += W2[k]
    return list(zip(toks, out))


# ---------------------------------------------------------------- icons
ICONS = {
    'check': '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    'x': '<path d="M7 7l10 10M17 7L7 17"/>',
    'clock': '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
    'film': '<rect x="3.5" y="5" width="17" height="14" rx="2.5"/><path d="M8 5v14M16 5v14M3.5 9.5H8M3.5 14.5H8M16 9.5h4.5M16 14.5h4.5"/>',
    'mail': '<rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3.5 7l8.5 6 8.5-6"/>',
    'doc': '<path d="M7 3.5h7l4.5 4.5v12.5H7z"/><path d="M14 3.5V8h4.5M9.5 12.5h6M9.5 16h6"/>',
    'pen': '<path d="M4.5 19.5l1-4.5L16 4.5l3.5 3.5L9 18.5z"/><path d="M13.5 7l3.5 3.5"/>',
    'gauge': '<path d="M4 17a8 8 0 1 1 16 0"/><path d="M12 17l4-5"/><circle cx="12" cy="17" r="1.2"/>',
    'coin': '<circle cx="12" cy="12" r="8.5"/><path d="M14.6 8.8a2.6 2.6 0 0 0-4.6 1.7V15M8.8 12.2h4.4M8.8 15.4h6"/>',
    'search': '<circle cx="10.5" cy="10.5" r="6"/><path d="M15 15l5 5"/>',
    'bolt': '<path d="M13 3L5.5 13.5H11L10 21l8-11h-5.5z"/>',
    'moon': '<path d="M19.5 14.5A7.5 7.5 0 1 1 9.5 4.5a6 6 0 0 0 10 10z"/>',
    'link': '<path d="M10 14a4 4 0 0 0 5.7 0l2.8-2.8a4 4 0 0 0-5.7-5.7L11.5 6.8"/><path d="M14 10a4 4 0 0 0-5.7 0l-2.8 2.8a4 4 0 0 0 5.7 5.7l1.3-1.3"/>',
    'user': '<circle cx="12" cy="8.5" r="3.8"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
    'gift': '<rect x="4" y="9" width="16" height="11" rx="1.5"/><path d="M3 9h18M12 9v11M12 9c-1.5-3.5-5.5-4-5.5-1.5S10 9 12 9zM12 9c1.5-3.5 5.5-4 5.5-1.5S14 9 12 9z"/>',
    'folder': '<path d="M3.5 7.5a2 2 0 0 1 2-2h4l2 2.5h7a2 2 0 0 1 2 2v7.5a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2z"/>',
    'bell': '<path d="M6 16.5V11a6 6 0 0 1 12 0v5.5l1.5 2h-15z"/><path d="M10 20.5a2 2 0 0 0 4 0"/>',
    'warn': '<path d="M12 4l9 16H3z"/><path d="M12 10v4.5M12 17.5v.1"/>',
    'chat': '<path d="M4.5 5.5h15v10h-8l-4.5 4v-4h-2.5z"/>',
    'cal': '<rect x="3.5" y="5" width="17" height="15" rx="2.5"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
    'play': '<path d="M8 5.5v13l10.5-6.5z"/>',
    'eye': '<path d="M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12z"/><circle cx="12" cy="12" r="2.8"/>',
    'reply': '<path d="M10 8l-5 4.5 5 4.5"/><path d="M5.5 12.5H14a5 5 0 0 1 5 5V19"/>',
    'code': '<path d="M8.5 7.5L4 12l4.5 4.5M15.5 7.5L20 12l-4.5 4.5M13.5 5l-3 14"/>',
    'chart': '<path d="M4 19.5h16"/><path d="M5 16l4.5-5 3.5 3 6-7"/>',
    'lock': '<rect x="5" y="10.5" width="14" height="10" rx="2"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
    'archive': '<rect x="3.5" y="4.5" width="17" height="4.5" rx="1"/><path d="M5 9v10.5h14V9M10 13h4"/>',
    'star': '<path d="M12 3.8l2.5 5.2 5.7.8-4.1 4 1 5.7-5.1-2.7-5.1 2.7 1-5.7-4.1-4 5.7-.8z"/>',
    'sun': '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>',
    'list': '<path d="M9 6.5h11M9 12h11M9 17.5h11"/><circle cx="4.8" cy="6.5" r="1.1"/><circle cx="4.8" cy="12" r="1.1"/><circle cx="4.8" cy="17.5" r="1.1"/>',
    'users': '<circle cx="9" cy="9" r="3.3"/><path d="M3 19.5a6 6 0 0 1 12 0"/><path d="M15.5 6a3.2 3.2 0 0 1 0 6.2M17.5 14.2a6 6 0 0 1 3.5 5.3"/>',
}


def svg(name):
    return ('<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" '
            'stroke-linecap="round" stroke-linejoin="round">' + ICONS[name] + '</svg>')


# ---------------------------------------------------------------- timing inside a card
class Beat:
    """Resolves `at` values to absolute times: a spoken word, seconds after the card lands, or '+0.4' after the last item."""

    def __init__(self, t0, words, sfx, lead=0.32):
        self.t0, self.words, self.sfx, self.lead = t0, words, sfx, lead
        self.pos, self.k, self.last = 0, 0, t0

    def at(self, at=None):
        if at is None:
            t = self.t0 + self.lead + 0.16 * self.k
            self.k += 1
            return round(t, 3)
        elif isinstance(at, (int, float)):
            t = self.t0 + float(at)
        elif isinstance(at, str) and at.startswith('+'):
            t = self.last + float(at[1:])
        else:
            key, t = norm(at), None
            for i in range(self.pos, len(self.words)):
                w = norm(self.words[i][0])
                if w == key or (len(key) >= 4 and w.startswith(key)):
                    t, self.pos = self.words[i][1], i + 1
                    break
            if t is None:
                print(f'  WARN word not found in beat: {at!r}', file=sys.stderr)
                t = self.last + 0.3
        self.last = t
        return round(t, 3)


def chip_html(ch, b, default_tone='acc'):
    t = b.at(ch.get('at'))
    b.sfx.append((t, 'tick'))
    icon = svg(ch['icon']) if ch.get('icon') else ''
    st = ' style="display:inline-flex;align-items:center;gap:8px"' if icon else ''
    return f'<div class="chip t-{ch.get("tone", default_tone)}" data-t="{t}" data-fx="pop"{st}>{icon}{esc(ch["text"])}</div>'


def chips_row(chs, b):
    return '<div class="chips">' + ''.join(chip_html(c, b) for c in chs) + '</div>' if chs else ''


def panel(p, b):
    t = b.at(p.get('at'))
    b.sfx.append((t, 'pop'))
    title = f'<div class="pt">{esc(p["title"])}</div>' if p.get('title') else ''
    return (f'<div class="panel t-{p.get("tone", "acc")}" data-t="{t}" data-fx="right">'
            f'{title}<div class="px">{esc(p["text"])}</div></div>')


def ic(name, tone='ink'):
    return f'<div class="ic t-{tone}">{svg(name)}</div>'


def fmt_code(s):
    s = esc(s)
    for tag in 'ksgcb':
        s = s.replace(f'[{tag}]', f'<span class="{tag}">').replace(f'[/{tag}]', '</span>')
    return s


# ---------------------------------------------------------------- card bodies
def b_rows(c, b):
    h = []
    if c.get('hero'):
        hv = c['hero']
        t = b.at(hv.get('at', 0.12))
        h.append(f'<div class="hero" data-t="{t}" data-fx="slam"><span class="v">{esc(hv["value"])}</span>'
                 f'<span class="l">{esc(hv.get("label", ""))}</span></div>')
    for it in c['items']:
        t = b.at(it.get('at'))
        tone = it.get('tone', 'ink')
        strike = ''
        if it.get('strike'):
            ts = b.at(it['strike_at']) if 'strike_at' in it else round(t + 0.3, 3)
            b.sfx.append((ts, 'swish'))
            strike = f'<i class="strike" data-t="{ts}" data-fx="strike"></i>'
        sub = f'<div class="sb">{esc(it["sub"])}</div>' if it.get('sub') else ''
        bar = ''
        if 'bar' in it:
            tb = b.at(it['bar_at']) if 'bar_at' in it else round(t + 0.1, 3)
            bar = (f'<div class="mbar"><i style="width:{float(it["bar"]) * 100:.0f}%" data-t="{tb}" '
                   f'data-fx="fill" data-dur="0.8"></i></div>')
        chip = ''
        if it.get('chip'):
            tc = b.at(it['chip_at']) if 'chip_at' in it else round(t + 0.28, 3)
            b.sfx.append((tc, 'tick'))
            chip = (f'<div class="chip t-{it.get("chip_tone", tone if tone != "ink" else "acc")}" '
                    f'data-t="{tc}" data-fx="pop">{esc(it["chip"])}</div>')
        icon = ic(it['icon'], tone) if it.get('icon') else ''
        h.append(f'<div class="row" data-t="{t}" data-fx="{"left" if getattr(b, "idx", 0) % 2 else "up"}">{icon}<div class="tx"><div class="lb">'
                 f'{esc(it["label"])}{strike}</div>{sub}{bar}</div>{chip}</div>')
    if c.get('panel'):
        h.append(panel(c['panel'], b))
    dense = len(c['items']) + (1 if c.get('hero') else 0) + (1 if c.get('panel') else 0) >= 4
    return f'<div class="rows{" dense" if dense else ""}">' + ''.join(h) + '</div>'


def b_big(c, b):
    items = []
    for it in c['items']:
        t = b.at(it.get('at'))
        b.sfx.append((t, 'pop'))
        suf = f'<small>{esc(it["suffix"])}</small>' if it.get('suffix') else ''
        val = esc(it['value'])
        if 'count_from' in it:
            tc = round(t + 0.05, 3)
            val = (f'<span data-t="{tc}" data-fx="count" data-from="{it["count_from"]}" data-to="{it["value"]}" '
                   f'data-dur="{it.get("dur", 0.8)}">{esc(it["value"])}</span>')
        items.append(f'<div class="bigitem" data-t="{t}" data-fx="slam"><div class="v" style="color:'
                     f'{it.get("color", "#111827")}">{val}{suf}</div><div class="l">{esc(it["label"])}</div></div>')
    note = ''
    if c.get('note'):
        tn = b.at(c['note'].get('at'))
        note = f'<div class="bnote" data-t="{tn}" data-fx="up">{esc(c["note"]["text"])}</div>'
    return f'<div class="bigwrap">{"".join(items)}</div>{note}' + chips_row(c.get('chips'), b)


def b_meter(c, b):
    f, to = int(c['from']), int(c['to'])
    N = int(c.get('segments', 10))
    mx = float(c.get('max', f))
    lit = lambda v: int(round(v * N / mx))
    t0 = b.at(c.get('at'))
    dur = float(c.get('dur', max(0.4, min(2.4, (f - to) * 0.32))))
    steps = f - to if 0 < f - to <= 24 else None
    l0, l1 = lit(f), lit(to)
    segs = []
    for i in range(N):
        if i >= l0:
            segs.append('<div class="seg off"></div>')
        elif i >= l1:
            k = (l0 - 1 - i)
            td = round(t0 + dur * (k + 1) / max(1, (l0 - l1)) - 0.05, 3)
            segs.append(f'<div class="seg" data-t="{td}" data-fx="dim"></div>')
        else:
            segs.append('<div class="seg"></div>')
    stp = f' data-steps="{steps}"' if steps else ''
    v = (f'<span class="v" data-t="{t0}" data-fx="count" data-from="{f}" data-to="{to}" data-dur="{dur}"{stp}>{f}</span>'
         if f != to else f'<span class="v">{f}</span>')
    stamp = ''
    if c.get('stamp'):
        tsx = b.at(c['stamp'].get('at'))
        b.sfx.append((tsx, 'stamp'))
        stamp = f'<div class="stamp" data-t="{tsx}" data-fx="stamp">{esc(c["stamp"]["text"])}</div>'
    sub = f'<div class="s">{esc(c["sub"])}</div>' if c.get('sub') else ''
    return (f'<div class="meter"><div class="top">{v}<div><div class="l">{esc(c["label"])}</div>{sub}</div></div>'
            f'<div class="segs">{"".join(segs)}</div>{stamp}</div>') + chips_row(c.get('chips'), b)


STATE = {
    'ok': ('t-ok', 'check', 'Ready'), 'fail': ('t-bad', 'x', 'Failed'), 'fixed': ('t-blue', 'check', 'Fixed'),
    'warn': ('t-warn', 'warn', 'Check'), 'empty': ('s-empty', None, 'Gap'), 'live': ('t-ok', 'play', 'Live'),
}


def st_html(st, show_text, text=None):
    cls, icon, label = STATE[st]
    label = text or label
    return (f'<div class="st {cls}">{svg(icon) if icon else ""}'
            f'{"<span>" + esc(label) + "</span>" if show_text or not icon else ""}</div>')


def b_slots(c, b):
    cols, rows = c['cols'], c['rows']
    show_text = c.get('labels', len(cols) <= 3)
    lw = c.get('label_w', 190)
    grid = f'grid-template-columns:{lw}px repeat({len(cols)},1fr)'
    t0 = b.at(c.get('at'))
    per = float(c.get('per', 0.09))
    flips = {}
    for fl in c.get('flips', []):
        tf = b.at(fl.get('at'))
        b.sfx.append((tf, 'stamp' if fl['to'] == 'fail' else 'tick'))
        flips[(fl['r'], fl['c'])] = (fl, tf)
    out = [f'<div class="sh" style="{grid}"><span></span>' + ''.join(f'<span>{esc(x)}</span>' for x in cols) + '</div>']
    k = 0
    for r, row in enumerate(rows):
        cells = []
        for ci, st in enumerate(row['cells']):
            t = round(t0 + k * per, 3)
            k += 1
            extra = ''
            if (r, ci) in flips:
                fl, tf = flips[(r, ci)]
                extra = st_html(fl['to'], show_text, fl.get('text')).replace('class="st ', f'data-t="{tf}" data-fx="flip" class="st ', 1)
            cells.append(f'<div class="cell" data-t="{t}" data-fx="flipst">{st_html(st, show_text)}{extra}</div>')
        out.append(f'<div class="sr" style="{grid}"><span class="rl">{esc(row["label"])}</span>{"".join(cells)}</div>')
    if c.get('note'):
        tn = b.at(c['note'].get('at'))
        b.sfx.append((tn, 'pop'))
        out.append(f'<div class="snote" data-t="{tn}" data-fx="up">{esc(c["note"]["text"])}</div>')
    return '<div class="slots">' + ''.join(out) + '</div>'


def b_notif(c, b):
    if c.get('empty'):
        t = b.at(c.get('at'))
        t2 = round(t + 0.25, 3)
        return (f'<div class="empty"><div class="big" data-t="{t}" data-fx="pop">{svg(c.get("icon", "moon"))}</div>'
                f'<div class="e1" data-t="{t2}" data-fx="up">{esc(c["heading"])}</div>'
                f'<div class="e2" data-t="{round(t2 + 0.15, 3)}" data-fx="up">{esc(c.get("text", ""))}</div></div>')
    clock = ''
    if c.get('clock'):
        tc = b.at(c.get('clock_at', 0.1))
        clock = (f'<div data-t="{tc}" data-fx="fade"><div class="ntime">{esc(c["clock"])}</div>'
                 f'<div class="nsub">{esc(c.get("clock_sub", ""))}</div></div>')
    t = b.at(c.get('at'))
    b.sfx.append((t, 'ping'))
    return (f'<div class="nwrap">{clock}<div class="nb" data-t="{t}" data-fx="drop"><div class="app">'
            f'{svg(c.get("icon", "bolt"))}</div><div class="nc"><div class="meta"><span>{esc(c["app"])}</span>'
            f'<span>{esc(c.get("time", "now"))}</span></div><div class="hd">{esc(c["heading"])}</div>'
            f'<div class="tx2">{esc(c.get("text", ""))}</div></div></div></div>') + chips_row(c.get('chips'), b)


def b_code(c, b):
    lines = []
    for ln in c['lines']:
        t = b.at(ln.get('at'))
        n = len(re.sub(r'\[/?[a-z]\]', '', ln['t']))
        lines.append(f'<div class="lw"><span class="ln" data-t="{t}" data-fx="type" data-n="{n}">{fmt_code(ln["t"])}</span></div>')
    prog = ''
    if c.get('progress'):
        p = c['progress']
        tp = b.at(p.get('at'))
        prog = (f'<div class="prog" data-t="{tp}" data-fx="fade"><span>{esc(p.get("label", ""))}</span><div class="pb">'
                f'<i data-t="{tp}" data-fx="fill" data-dur="{p.get("dur", 1.2)}"></i></div>'
                f'<span>{esc(p.get("end", ""))}</span></div>')
    return f'<div class="code">{"".join(lines)}{prog}</div>' + chips_row(c.get('chips'), b)


def b_grid(c, b):
    tiles = []
    for tl_ in c['tiles']:
        t = b.at(tl_.get('at'))
        b.sfx.append((t, 'tick'))
        sub = f'<div class="ts">{esc(tl_["sub"])}</div>' if tl_.get('sub') else ''
        tiles.append(f'<div class="tile" data-t="{t}" data-fx="flip">{ic(tl_["icon"], tl_.get("tone", "acc"))}'
                     f'<div class="tl">{esc(tl_["label"])}</div>{sub}</div>')
    cls = 'grid compact' if c.get('compact') else 'grid'
    return (f'<div class="{cls}" style="grid-template-columns:repeat({c.get("cols", 3)},1fr)">{"".join(tiles)}</div>'
            + chips_row(c.get('chips'), b))


def b_email(c, b):
    t = b.at(c.get('at', 0.1))
    marks = list(c.get('marks_at', []))

    def repl(m):
        tm = b.at(marks.pop(0) if marks else None)
        b.sfx.append((tm, 'swish'))
        return f'<span class="mk mk-{m.group(1)}" data-t="{tm}" data-fx="mark">{m.group(2)}</span>'

    paras = ''.join('<p>' + re.sub(r'\[(bad|hl)\](.*?)\[/\1\]', repl, esc(p)) + '</p>' for p in c['body'])
    head = (f'<div class="f">To: <b>{esc(c["to"])}</b></div>'
            f'<div class="f">Subject: <b>{esc(c["subject"])}</b></div>')
    return (f'<div class="em">{head}<div class="eb" data-t="{t}" data-fx="up">{paras}</div>'
            + chips_row(c.get('chips'), b) + '</div>')


def b_site(c, b):
    t = b.at(c.get('at', 0.1))
    heading = esc(c['heading'])
    if c.get('mark'):
        tm = b.at(c['mark'].get('at'))
        b.sfx.append((tm, 'swish'))
        mk = esc(c['mark']['text'])
        heading = heading.replace(mk, f'<span class="mk mk-hl" data-t="{tm}" data-fx="mark">{mk}</span>', 1)
    sub = f'<div class="ss">{esc(c["sub"])}</div>' if c.get('sub') else ''
    out = (f'<div class="site"><div class="url">{svg("lock")}<span>{esc(c["url"])}</span></div>'
           f'<div data-t="{t}" data-fx="left"><h3>{heading}</h3>{sub}</div>')
    out += chips_row(c.get('chips'), b)
    if c.get('panel'):
        out += panel(c['panel'], b)
    return out + '</div>'


def bez(p0, p1, p2, p3, s):
    return tuple((1 - s) ** 3 * p0[i] + 3 * (1 - s) ** 2 * s * p1[i] + 3 * (1 - s) * s * s * p2[i] + s ** 3 * p3[i]
                 for i in range(2))


def b_chart(c, b):
    W, Hh = 892, 300
    t0 = b.at(c.get('at'))
    out = [f'<svg width="{W}" height="282" viewBox="0 0 {W} {Hh}" style="overflow:visible">',
           f'<line x1="30" y1="270" x2="{W - 10}" y2="270" stroke="#111827" stroke-width="4" opacity=".25"/>']
    if c.get('mode') == 'rewrite':
        hope = ((40, 230), (300, 200), (520, 120), (800, 40))
        real_pts = [(40, 230), (200, 236), (360, 244), (520, 250)]
        new = ((520, 250), (620, 246), (720, 238), (800, 226))
        out.append(f'<path d="M{hope[0][0]} {hope[0][1]} C {hope[1][0]} {hope[1][1]}, {hope[2][0]} {hope[2][1]}, '
                   f'{hope[3][0]} {hope[3][1]}" fill="none" stroke="#9CA3AF" stroke-width="8" stroke-dasharray="4 18" '
                   f'stroke-linecap="round" data-t="{t0}" data-fx="fade"/>')
        out.append(f'<text x="806" y="36" font-family="Archivo" font-weight="800" font-size="28" fill="#6B7280" '
                   f'data-t="{t0}" data-fx="fade">Hope</text>')
        d = 'M' + ' L'.join(f'{x} {y}' for x, y in real_pts)
        tr = b.at(c.get('real_at'))
        out.append(f'<path d="{d}" fill="none" stroke="#111827" stroke-width="10" stroke-linecap="round" '
                   f'stroke-linejoin="round" data-t="{tr}" data-fx="draw" data-dur="0.9"/>')
        for i, (x, y) in enumerate(real_pts[1:], 1):
            out.append(f'<circle cx="{x}" cy="{y}" r="11" fill="#DC2626" stroke="#111827" stroke-width="4" '
                       f'data-t="{round(tr + 0.3 * i, 3)}" data-fx="pop"/>')
            out.append(f'<text x="{x - 30}" y="{y + 44}" font-family="Archivo" font-weight="800" font-size="24" '
                       f'fill="#B91C1C" data-t="{round(tr + 0.3 * i, 3)}" data-fx="fade">Wk {i}</text>')
        tn = b.at(c.get('new_at'))
        out.append(f'<path d="M{new[0][0]} {new[0][1]} C {new[1][0]} {new[1][1]}, {new[2][0]} {new[2][1]}, '
                   f'{new[3][0]} {new[3][1]}" fill="none" stroke="#FF5A1F" stroke-width="10" stroke-linecap="round" '
                   f'data-t="{tn}" data-fx="draw" data-dur="0.8"/>')
        out.append(f'<text x="812" y="232" font-family="Archivo" font-weight="800" font-size="28" fill="#E8480F" '
                   f'data-t="{round(tn + 0.6, 3)}" data-fx="fade">Real</text>')
        b.sfx.append((tn, 'swish'))
    else:
        lines = {'Fast': ((40, 250), (300, 230), (520, 130), (800, 34), '#15803D'),
                 'Base': ((40, 250), (300, 240), (560, 180), (800, 122), '#FF5A1F'),
                 'Slow': ((40, 250), (300, 252), (560, 236), (800, 212), '#6B7280')}
        for i, (name, (p0, p1, p2, p3, col)) in enumerate(lines.items()):
            ti = round(t0 + 0.18 * i, 3)
            out.append(f'<path d="M{p0[0]} {p0[1]} C {p1[0]} {p1[1]}, {p2[0]} {p2[1]}, {p3[0]} {p3[1]}" fill="none" '
                       f'stroke="{col}" stroke-width="9" stroke-linecap="round" data-t="{ti}" data-fx="draw" data-dur="0.9"/>')
            out.append(f'<text x="{p3[0] + 14}" y="{p3[1] + 10}" font-family="Archivo" font-weight="800" font-size="28" '
                       f'fill="{col}" data-t="{round(ti + 0.7, 3)}" data-fx="fade">{name}</text>')
        for dot in c.get('dots', []):
            td = b.at(dot.get('at'))
            b.sfx.append((td, 'tick'))
            p0, p1, p2, p3, col = lines[dot['line']]
            x, y = bez(p0, p1, p2, p3, float(dot.get('s', 0.6)))
            out.append(f'<g data-t="{td}" data-fx="pop"><circle cx="{x:.0f}" cy="{y:.0f}" r="24" fill="#FFFDF8" '
                       f'stroke="#111827" stroke-width="5"/><text x="{x:.0f}" y="{y + 9:.0f}" text-anchor="middle" '
                       f'font-family="Archivo" font-weight="900" font-size="26" fill="#111827">{esc(dot["label"])}</text></g>')
    out.append('</svg>')
    res = '<div class="chart">' + ''.join(out)
    if c.get('panel'):
        res += panel(c['panel'], b)
    return res + '</div>'


def b_chat(c, b):
    bs = []
    for x in c['bubbles']:
        t = b.at(x.get('at'))
        b.sfx.append((t, 'ping'))
        who = f'<span class="who">{esc(x["who"])}</span>' if x.get('who') else ''
        bs.append(f'<div class="bub {x["from"]}" data-t="{t}" data-fx="bubble">{who}{esc(x["text"])}</div>')
    return '<div class="chat">' + ''.join(bs) + '</div>'


BODIES = {'rows': b_rows, 'big': b_big, 'meter': b_meter, 'slots': b_slots, 'notif': b_notif, 'code': b_code,
          'grid': b_grid, 'email': b_email, 'site': b_site, 'chart': b_chart, 'chat': b_chat}


def card_html(c, b, tin, tout, tr='push', trout='push', tilt='l'):
    body = BODIES[c['type']](c, b)
    cls = ' dark' if c.get('theme') == 'dark' else ''
    out_attr = f' data-out="{tout}"' if tout is not None else ''
    return (f'<div class="cardw" data-in="{tin}"{out_attr} data-tr="{tr}" data-trout="{trout}" data-tilt="{tilt}">'
            f'<div class="card{cls}"><div class="bar"><i class="d d1"></i><i class="d"></i><i class="d"></i>'
            f'<span class="ttl">{esc(c.get("title", ""))}</span></div><div class="body">{body}</div></div></div>')


def burst_html():
    out = []
    for side in (-1, 1):
        for k in range(5):
            ang = math.radians(-40 + 20 * k)
            x = side * (322 + 26 * math.cos(ang))
            y = 92 * math.sin(ang)
            deg = math.degrees(math.atan2(y, x)) + 90
            ln = 30 + (k * 9) % 22
            out.append(f'<i style="left:{x:.0f}px;top:{y:.0f}px;height:{ln}px;transform:translate(-50%,-50%) rotate({deg:.0f}deg)"></i>')
    return '<div class="burst">' + ''.join(out) + '</div>'


def cta_html(cta, b, tin):
    k = cta['keyword']
    t1 = b.at(0.12)
    t2 = b.at(cta.get('at', 0.3))
    b.sfx.append((t2, 'pop'))
    t3 = round(t2 + 0.35, 3)
    t4 = round(t3 + 0.3, 3)
    return (f'<div class="cardw" data-in="{tin}" data-tr="zoom" data-tilt="r"><div class="card cta"><div class="bar"><i class="d d1"></i>'
            f'<i class="d"></i><i class="d"></i><span class="ttl">comment-for-the-link</span></div><div class="body">'
            f'<div class="cta-k" data-t="{t1}" data-fx="up">{esc(cta.get("kicker", "Want it?"))}</div>'
            f'<div class="pillwrap">{burst_html()}<div class="cta-pill" data-t="{t2}" data-fx="slam">{svg("chat")}<span>Comment</span>'
            f'<b>{esc(k)}</b></div></div>'
            f'<div class="cta-sub" data-t="{t3}" data-fx="up">{esc(cta["sub"])}</div>'
            f'<div class="cta-foot" data-t="{t4}" data-fx="fade">{esc(cta.get("foot", "Sent straight to your DMs."))}</div>'
            f'</div></div></div>'), t2


# ---------------------------------------------------------------- captions
def cap_groups(show, maxw=3, maxc=20):
    ws = show.split()
    out, cur = [], []
    for i, w in enumerate(ws):
        if cur and (len(cur) >= maxw or len(' '.join([x for _, x in cur] + [w])) > maxc):
            out.append(cur)
            cur = []
        cur.append((i, w))
        if w[-1] in PUN:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    if len(out) >= 2 and len(out[-1]) == 1 and len(' '.join(x for _, x in out[-2] + out[-1])) <= maxc + 3:
        out[-2] += out[-1]
        out.pop()
    return out


def fit_size(text, ttf, max_w, max_size, tracking=0.0):
    path = os.path.join(ENGINE, 'ttf', ttf)
    try:
        from PIL import ImageFont
        ImageFont.truetype(path, 10)
    except Exception:
        return int(min(max_size, max_w / (0.72 * max(1, len(text)))))
    from PIL import ImageFont
    size = max_size
    while size > 20:
        f = ImageFont.truetype(path, size)
        if f.getlength(text) + tracking * size * len(text) <= max_w:
            return size
        size -= 1
    return size


# ---------------------------------------------------------------- audio
def music(T, seed, bpm=96):
    rng = np.random.default_rng(seed)
    n = int(T * SR)
    t = np.arange(n) / SR
    beat = 60.0 / bpm
    progs = [
        [[48, 52, 55, 59], [45, 52, 55, 60], [41, 53, 57, 60], [43, 55, 59, 62]],
        [[45, 52, 57, 60], [41, 53, 57, 60], [48, 52, 55, 59], [43, 50, 55, 59]],
        [[41, 53, 57, 64], [43, 55, 59, 62], [45, 52, 57, 60], [48, 52, 55, 59]],
    ]
    prog = progs[seed % len(progs)]
    f = lambda m: 440.0 * 2 ** ((m - 69) / 12.0)
    out = np.zeros(n, dtype=np.float64)
    bar = beat * 4
    span = bar * 2
    k = 0
    while k * span < T + span:
        ch = prog[k % len(prog)]
        s0 = k * span
        a, z = int(max(0, s0 - 0.3) * SR), int(min(T, s0 + span + 0.6) * SR)
        if a >= n:
            break
        tt = t[a:z] - s0
        env = np.clip((tt + 0.3) / 0.7, 0, 1) * np.clip((span + 0.6 - tt) / 0.9, 0, 1)
        for m in ch:
            for det in (-0.06, 0.0, 0.07):
                fr = f(m) * 2 ** (det / 12)
                ph = rng.uniform(0, 6.28)
                w = np.sin(2 * np.pi * fr * tt + ph) + 0.28 * np.sin(4 * np.pi * fr * tt + ph) + 0.1 * np.sin(6 * np.pi * fr * tt)
                out[a:z] += 0.035 * env * w
        # bass with a harmonic so phones can hear it
        root = f(ch[0] - 12)
        out[a:z] += 0.05 * env * (np.sin(2 * np.pi * root * tt) + 0.5 * np.sin(4 * np.pi * root * tt))
        # pluck arpeggio, eighth notes
        steps = int(span / (beat / 2))
        pattern = [0, 1, 2, 3, 2, 1, 2, 3]
        for s in range(steps):
            ts = s0 + s * beat / 2
            if ts >= T:
                break
            note = ch[pattern[s % 8]] + 12
            a2, z2 = int(ts * SR), min(n, int((ts + 0.6) * SR))
            if a2 >= n:
                break
            t2 = t[a2:z2] - ts
            vel = 0.075 * (0.8 + 0.4 * rng.random()) * (1.15 if s % 4 == 0 else 1.0)
            out[a2:z2] += vel * np.exp(-t2 / 0.16) * (np.sin(2 * np.pi * f(note) * t2) + 0.25 * np.sin(4 * np.pi * f(note) * t2))
        k += 1
    # soft off-beat hat
    for s in range(int(T / beat)):
        ts = s * beat + beat / 2
        a2 = int(ts * SR)
        z2 = min(n, a2 + int(0.035 * SR))
        if a2 >= n:
            break
        nz = rng.standard_normal(z2 - a2)
        nz = np.diff(np.concatenate([[0], nz]))
        out[a2:z2] += 0.018 * nz * np.exp(-np.arange(z2 - a2) / (0.008 * SR))
    fade_in = np.clip(t / 0.6, 0, 1)
    fade_out = np.clip((T - t) / 1.2, 0, 1)
    out *= fade_in * fade_out
    return out / (np.max(np.abs(out)) + 1e-9)


def sfx_sound(kind, rng):
    if kind == 'tick':
        d = 0.05
        tt = np.arange(int(d * SR)) / SR
        return 0.16 * np.exp(-tt / 0.012) * (np.sin(2 * np.pi * 1850 * tt) + 0.35 * np.sin(2 * np.pi * 3700 * tt))
    if kind == 'ping':
        d = 0.35
        tt = np.arange(int(d * SR)) / SR
        return 0.13 * np.exp(-tt / 0.09) * (np.sin(2 * np.pi * 1320 * tt) + 0.5 * np.sin(2 * np.pi * 1980 * tt))
    if kind == 'pop':
        d = 0.12
        tt = np.arange(int(d * SR)) / SR
        fr = 820 * np.exp(-tt / 0.05) + 260
        return 0.32 * np.exp(-tt / 0.04) * np.sin(2 * np.pi * np.cumsum(fr) / SR)
    if kind == 'stamp':
        d = 0.22
        tt = np.arange(int(d * SR)) / SR
        thump = np.sin(2 * np.pi * (140 * np.exp(-tt / 0.06) + 55) * tt) * np.exp(-tt / 0.06)
        click = rng.standard_normal(len(tt)) * np.exp(-tt / 0.006)
        return 0.42 * thump + 0.08 * click
    # swish / whoosh: filtered noise
    d = 0.18 if kind == 'swish' else 0.34
    m = int(d * SR)
    nz = rng.standard_normal(m)
    spec = np.fft.rfft(nz)
    fq = np.fft.rfftfreq(m, 1 / SR)
    centre, width = (3200, 1800) if kind == 'swish' else (1400, 1100)
    spec *= np.exp(-((fq - centre) / width) ** 2)
    nz = np.fft.irfft(spec, m)
    nz /= np.max(np.abs(nz)) + 1e-9
    tt = np.arange(m) / SR
    env = np.sin(np.pi * tt / d) ** 2
    return (0.05 if kind == 'swish' else 0.11) * nz * env


def mix_audio(vo, T, sfx, seed, with_music=False):
    n = int(T * SR)
    vo = np.pad(vo, (0, max(0, n - len(vo))))[:n].astype(np.float64)
    rng = np.random.default_rng(seed + 7)
    mus = music(T, seed) if with_music else np.zeros(n)
    # duck the music under the voice
    hop = int(0.01 * SR)
    env = np.array([np.sqrt(np.mean(vo[i:i + hop] ** 2)) for i in range(0, n, hop)])
    act = (env > 0.01).astype(float)
    k = np.ones(25) / 25
    act = np.clip(np.convolve(act, k, mode='same') * 1.6, 0, 1)
    duck = np.repeat(1.0 - 0.45 * act, hop)[:n]
    out = vo * 0.92 + mus * 0.085 * duck
    last = {}
    for t, kind in sorted(sfx):
        if t < 0 or t >= T:
            continue
        gap = 0.22 if kind in ('tick', 'swish') else 0.12
        if t - last.get(kind, -9) < gap:
            continue
        last[kind] = t
        s = sfx_sound(kind, rng)
        a = int(t * SR)
        z = min(n, a + len(s))
        out[a:z] += s[:z - a]
    peak = np.max(np.abs(out))
    if peak > 0.98:
        out *= 0.98 / peak
    return out.astype(np.float32)


def mouth_env(vo, T):
    n_frames = int(round(T * FPS)) + 1
    hop = SR // FPS
    vals = []
    for i in range(n_frames):
        c = i * hop
        seg = vo[max(0, c - hop // 2):c + hop // 2] if c < len(vo) else np.zeros(1)
        vals.append(float(np.sqrt(np.mean(seg ** 2))) if len(seg) else 0.0)
    v = np.array(vals)
    voiced = v[v > 0.01]
    ref = np.percentile(voiced, 90) if len(voiced) else 1.0
    o = np.clip((v / ref) ** 0.8, 0, 1.0)
    o[v < 0.008] = 0
    y, sm = 0.0, []
    for x in o:
        y = x if x > y else y * 0.55 + x * 0.45
        sm.append(y)
    return [round(0.2 + 0.85 * s, 2) for s in sm]


# ---------------------------------------------------------------- build
def align_words(a, text):
    """Word start/end times (s) for `text` in audio `a` (SR), using pocketsphinx forced alignment. None if it fails."""
    try:
        from pocketsphinx import Decoder
        from scipy.signal import resample_poly
        pcm = resample_poly(a, 2, 3)  # 24 kHz -> 16 kHz
        pcm = (np.clip(pcm, -1, 1) * 32767).astype(np.int16).tobytes()
        clean = ' '.join(re.sub(r"[^a-z']", '', w.lower().replace('’', "'")) for w in text.split())
        dec = Decoder(samprate=16000, loglevel='FATAL')
        dec.set_align_text(clean)
        dec.start_utt()
        dec.process_raw(pcm, full_utt=True)
        dec.end_utt()
        segs = [(re.sub(r'\(\d+\)$', '', sg.word), sg.start_frame / 100.0, (sg.end_frame + 1) / 100.0) for sg in dec.seg()
                if not (sg.word.startswith('<') or sg.word.startswith('[') or sg.word.startswith('+') or sg.word == '(NULL)')]
        n = len(clean.split())
        return segs if len(segs) == n else None
    except Exception as e:  # noqa: BLE001
        print('  align failed:', type(e).__name__, e, file=sys.stderr)
        return None


def voice_from_file(spec, path):
    a, sr = sf.read(path, dtype='float32', always_2d=True)
    a = a.mean(axis=1)
    if sr != SR:
        from scipy.signal import resample_poly
        g = math.gcd(sr, SR)
        a = resample_poly(a, SR // g, sr // g).astype(np.float32)
    a = trim(a)
    lines = spec['lines']
    full = ' '.join(ln['say'] for ln in lines)
    segs = align_words(a, full)
    if segs is None:
        print('  alignment fell back to pause-based timing', file=sys.stderr)
        wt = word_times(full, a)
        segs = [(w, t, (wt[i + 1][1] if i + 1 < len(wt) else len(a) / SR)) for i, (w, t) in enumerate(wt)]
    starts, words_abs, k = [], [], 0
    for ln in lines:
        toks = ln['say'].split()
        mine = segs[k:k + len(toks)]
        k += len(toks)
        starts.append(round(LEAD + mine[0][1], 3))
        ln['_end'] = round(LEAD + mine[-1][2], 3)
        words_abs.append([(tok, round(LEAD + sg[1], 3)) for tok, sg in zip(toks, mine)])
    vo = np.concatenate([np.zeros(int(LEAD * SR), dtype=np.float32), a])
    return vo, starts, words_abs


def build(spec_path, out_root):
    spec = json.load(open(spec_path))
    n, slug = spec['n'], spec['slug']
    name = f'{n:02d}_{slug}'
    out = os.path.join(out_root, name)
    os.makedirs(os.path.join(out, 'audio'), exist_ok=True)
    cache = os.path.join(ENGINE, '.tts_cache')
    lines = spec['lines']
    cta_line = spec['cta']['line']
    vspec = spec.get('voice', 'af_heart')
    vofile = spec.get('voice_file')
    if vofile and not os.path.isabs(vofile):
        vofile = os.path.join(os.path.dirname(os.path.abspath(spec_path)), '..', vofile)

    # 1. voice: a narration file (Gemini) aligned word by word, or Kokoro line by line
    if vofile and os.path.exists(vofile):
        vo, starts, words_abs = voice_from_file(spec, vofile)
        voice_used = 'file:' + os.path.basename(vofile)
    else:
        voice, speed = (vspec, float(spec.get('speed', 1.05))) if isinstance(vspec, str) else (vspec['id'], float(vspec.get('speed', 1.05)))
        voice_used = voice
        t = LEAD
        segs, starts, words_abs = [], [], []
        for i, ln in enumerate(lines):
            say = ln['say']
            a = tts(say, voice, speed, cache)
            wt = word_times(say, a)
            starts.append(round(t, 3))
            words_abs.append([(w, round(t + wtt, 3)) for w, wtt in wt])
            segs.append((t, a))
            end = t + len(a) / SR
            gap = 0.42 if i + 1 == cta_line else (0.16 if say.rstrip()[-1] in ',:' else 0.30)
            ln['_end'] = round(end, 3)
            t = end + float(ln.get('gap', gap))
        vo = np.zeros(int((t + 1) * SR), dtype=np.float32)
        for st, a in segs:
            i0 = int(st * SR)
            vo[i0:i0 + len(a)] += a
    T = round(lines[-1]['_end'] + HOLD, 2)
    vo = np.pad(vo, (0, max(0, int(T * SR) - len(vo))))[:int(T * SR)]

    # 2. beats -> cards, with velocity-matched transitions (the next card's type is the current card's exit)
    sfx = []
    beats = sorted(spec['beats'], key=lambda x: x['line'])
    tins = []
    for k, bt in enumerate(beats):
        tin = 0.35 if k == 0 else max(round(starts[bt['line']] - 0.2, 3), tins[-1] + 0.8)
        tins.append(round(tin, 3))
    t_cta = round(starts[cta_line] - 0.25, 3)
    pattern = ['push', 'whip', 'push', 'push', 'whip']
    trs = ['drop'] + [beats[k].get('tr', pattern[(k - 1) % len(pattern)]) for k in range(1, len(beats))]
    cards_html, card_done = [], []
    for k, bt in enumerate(beats):
        l0 = bt['line']
        l1 = beats[k + 1]['line'] if k + 1 < len(beats) else cta_line
        words = [w for li in range(l0, l1) for w in words_abs[li]]
        tout = tins[k + 1] if k + 1 < len(beats) else t_cta
        trout = trs[k + 1] if k + 1 < len(beats) else 'zoom'
        b = Beat(tins[k], words, sfx, lead=0.4 if k == 0 else 0.32)
        b.idx = k
        sfx.append((tins[k], 'whoosh'))
        cards_html.append(card_html(bt['card'], b, tins[k], tout, trs[k], trout, 'l' if k % 2 else 'r'))
        card_done.append(max([float(x) for x in re.findall(r'data-t="([0-9.]+)"', cards_html[-1])] or [tins[k]]))
    bc = Beat(t_cta, words_abs[cta_line], sfx)
    sfx.append((t_cta, 'whoosh'))
    cta_card, t_hit = cta_html({**spec['cta'], 'keyword': spec['keyword']}, bc, t_cta)
    cards_html.append(cta_card)
    sfx.append((t_hit + 0.02, 'stamp'))

    # 3. captions: 2 to 3 word groups, each word lit as it is spoken
    pill = {norm(spec['keyword']), 'free'}
    accent = {norm(x) for x in spec.get('em', [])} | {'claude'}
    caps, nods = [], []
    for i, ln in enumerate(lines):
        show = ln.get('show', ln['say'])
        groups = cap_groups(show)
        n_show, n_say = len(show.split()), len(words_abs[i])
        wtime = lambda si: words_abs[i][min(n_say - 1, int(round(si * n_say / max(1, n_show))))][1]
        g_t0 = [max(starts[i] - 0.05, wtime(g[0][0]) - 0.06) for g in groups]
        next_start = starts[i + 1] if i + 1 < len(lines) else T
        for gi, g in enumerate(groups):
            t0 = round(g_t0[gi], 3)
            t1 = round(g_t0[gi + 1] if gi + 1 < len(groups) else min(next_start - 0.06, ln['_end'] + 0.45), 3)
            t1 = max(t1, round(t0 + 0.25, 3))
            spans = []
            for si, w in g:
                core = norm(w)
                cls = 'kp' if core in pill else ('ka' if (any(ch.isdigit() for ch in w) or core in accent) else '')
                tw = round(wtime(si), 3)
                if cls:
                    nods.append(tw)
                spans.append(f'<span class="cw {cls}" data-t="{tw}">{esc(w)}</span>')
            gtxt = ' '.join(w for _, w in g)
            gfs = fit_size(gtxt, 'archivo-latin-900-normal.ttf', 800 - 20 * len(g), 64)
            caps.append(f'<div class="cg" data-t0="{t0}" data-t1="{t1}" style="font-size:{gfs}px">{" ".join(spans)}</div>')
    nod_times = []
    for t in sorted(nods):
        if not nod_times or t - nod_times[-1] > 0.9:
            nod_times.append(round(t, 3))

    # 4. robot, CTA burst and confetti
    rng = np.random.default_rng(n * 101)
    blinks, tb = [], 1.6
    while tb < T - 0.5:
        blinks.append(round(tb, 2))
        tb += 2.6 + 1.8 * rng.random()
    taps = [round(x + 0.05, 3) for x in tins[1:]] + [round(t_cta + 0.05, 3)]
    confetti, pieces = [], []
    cols = ['#FF5A1F', '#2563EB', '#111827', '#6EF0D2', '#FF8A5B']
    for i in range(28):
        ang = math.radians(-170 + 160 * rng.random())
        spd = 260 + 380 * rng.random()
        c = {'dx': round(math.cos(ang) * spd, 1), 'up': round(math.sin(ang) * spd * 0.9, 1),
             'fall': round(520 + 420 * rng.random(), 1), 'r': round((360 + 540 * rng.random()) * (1 if i % 2 else -1)),
             'd': round(1.3 + 0.7 * rng.random(), 2), 'delay': round(0.06 * rng.random(), 3)}
        confetti.append(c)
        w, h = (14, 24) if i % 3 else (18, 18)
        rad = '50%' if i % 3 == 0 else '3px'
        pieces.append(f'<i id="cf{i}" style="width:{w}px;height:{h}px;margin:-{h // 2}px 0 0 -{w // 2}px;'
                      f'background:{cols[i % len(cols)]};border-radius:{rad}"></i>')
    plan = {'total': T, 'cta': {'in': t_cta, 'hit': t_hit}, 'confetti': confetti,
            'robot': {'fps': FPS, 'mouth': mouth_env(vo, T), 'blinks': blinks, 'taps': [0.95] + taps, 'nods': nod_times}}

    # keyword tag
    t_tag = round(max(2.6, tins[1] + 0.7 if len(tins) > 1 else 2.6), 3)
    kwfs = fit_size(spec['keyword'], 'archivo-latin-900-normal.ttf', 262, 60, 0.02)
    kw = (f'<div class="kwtag" data-t0="{t_tag}" data-t1="{t_cta}"><div class="a">Comment</div>'
          f'<div class="b" style="font-size:{kwfs}px">{esc(spec["keyword"])}</div>'
          f'<div class="c">{esc(spec.get("tag_sub", "for the free skill"))}</div></div>')
    sfx.append((t_tag, 'pop'))

    # 5. html
    css = open(os.path.join(ENGINE, 'reel.css')).read()
    js = open(os.path.join(ENGINE, 'runtime.js')).read()
    robot = open(os.path.join(ENGINE, 'robot.svg')).read()
    h1, h2 = spec['headline']
    hs = spec.get('headline_size', [78, 72])
    h1_html = ' '.join(f'<span class="w"><span class="wi">{esc(w)}</span></span>' for w in h1.split())
    ghost_fs = fit_size(spec['keyword'], 'fraunces-latin-900-normal.ttf', 1400, 380)
    doc = f'''<!doctype html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=1080, height=1920">
<title>{esc(name)}</title>
<style>
{css}
</style>
<script src="gsap.min.js"></script>
</head>
<body>
<div id="root" data-composition-id="main" data-width="1080" data-height="1920" data-start="0" data-duration="{T}" data-fps="{FPS}">
<div class="bg-dots"></div>
<div class="glow g1"></div><div class="glow g2"></div>
<div class="ghost" style="font-size:{ghost_fs}px">{esc(spec['keyword'])}</div>
<div class="grain"></div>
<div class="meta"><span class="m1">No. {n:02d}</span><span class="m2">Claude skills for beginners</span><i class="rule"></i></div>
<div class="head"><div class="h1" style="font-size:{hs[0]}px">{h1_html}</div><div class="h2" style="font-size:{hs[1]}px"><span class="h2t">{esc(h2)}</span><i class="u"></i></div></div>
<div class="cam"><div class="stage">
{chr(10).join(cards_html)}
</div></div>
<div class="caps">
{chr(10).join(caps)}
</div>
<div class="shadow"></div>
<div id="robotWrap"><div id="robotBob">{robot}</div></div>
{kw}
<div class="confetti">{''.join(pieces)}</div>
<div class="flash"></div>
<audio id="mix" data-start="0" data-duration="{T}" data-track-index="5" src="audio/mix.wav" data-volume="1"></audio>
<script>window.__PLAN = {json.dumps(plan, separators=(',', ':'))};</script>
<script>
{js}
</script>
</div>
</body>
</html>
'''
    open(os.path.join(out, 'index.html'), 'w').write(doc)

    # 6. audio: voice + sound effects (music is added in Instagram when posting)
    mix = mix_audio(vo, T, sfx, n, with_music=bool(spec.get('music')))
    raw = os.path.join(out, 'audio', 'mix_raw.wav')
    sf.write(raw, mix, SR)
    sf.write(os.path.join(out, 'audio', 'vo.wav'), vo, SR)
    subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', raw, '-af',
                    'highpass=f=70,equalizer=f=220:t=q:w=1:g=-1.5,equalizer=f=3500:t=q:w=1.4:g=2,'
                    'acompressor=threshold=0.12:ratio=3:attack=8:release=90:makeup=1.5,loudnorm=I=-14:TP=-1.5:LRA=11',
                    '-ar', '48000', '-ac', '2', os.path.join(out, 'audio', 'mix.wav')], check=True)
    os.remove(raw)

    # 7. assets
    ensure_gsap()
    shutil.copy(os.path.join(ENGINE, 'gsap.min.js'), out)
    shutil.copy(os.path.join(ENGINE, 'grain.png'), out)
    if os.path.exists(os.path.join(out, 'fonts')):
        shutil.rmtree(os.path.join(out, 'fonts'))
    shutil.copytree(os.path.join(ENGINE, 'fonts'), os.path.join(out, 'fonts'))
    meta = {'name': name, 'total': T, 'voice': voice_used, 'starts': starts, 'cards_in': tins, 'cta_in': t_cta, 'cta_hit': t_hit,
            'cover_t': round(min(card_done[0] + 0.6, (tins[1] if len(tins) > 1 else t_cta) - 0.05), 2),
            'card_done': [round(x, 2) for x in card_done], 'keyword': spec['keyword']}
    json.dump(meta, open(os.path.join(out, 'meta.json'), 'w'), indent=1)
    print(f'{name}: {T}s, voice {voice_used}, {len(beats)} cards + CTA, {len(caps)} caption groups')
    return out


def ensure_gsap():
    p = os.path.join(ENGINE, 'gsap.min.js')
    if os.path.exists(p):
        return
    import tempfile
    tmp = tempfile.mkdtemp()
    subprocess.run(['npm', 'pack', 'gsap@3.14.2', '--silent'], cwd=tmp, check=True)
    subprocess.run(['tar', 'xzf', 'gsap-3.14.2.tgz'], cwd=tmp, check=True)
    shutil.copy(os.path.join(tmp, 'package', 'dist', 'gsap.min.js'), p)


def grain():
    p = os.path.join(ENGINE, 'grain.png')
    if os.path.exists(p):
        return
    from PIL import Image
    rng = np.random.default_rng(3)
    a = np.zeros((256, 256, 4), dtype=np.uint8)
    lum = rng.integers(0, 255, (256, 256))
    a[..., 0] = a[..., 1] = a[..., 2] = np.where(lum > 127, 255, 0)
    a[..., 3] = (np.abs(lum - 127) / 127 * 14).astype(np.uint8)
    Image.fromarray(a, 'RGBA').save(p)


if __name__ == '__main__':
    args = sys.argv[1:]
    out_root = os.path.join(ENGINE, '..', 'build')
    if '--out' in args:
        i = args.index('--out')
        out_root = args[i + 1]
        del args[i:i + 2]
    grain()
    for sp in args:
        build(sp, out_root)
