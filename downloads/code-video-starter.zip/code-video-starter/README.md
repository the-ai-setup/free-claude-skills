# Reel engine

Turns a short script into a 1080x1920 reel: a kinetic headline, cards that blur and push between beats, word-by-word captions, a robot presenter whose mouth follows the voice, sound effects and a confetti ending. Music is left out on purpose, so a track can be added in Instagram or TikTok when posting. Everything is code, so a new video costs nothing to make.

## Needs

- Python 3 with `numpy`, `soundfile`, `pillow`, `kokoro-onnx` (`pip install numpy soundfile pillow kokoro-onnx --break-system-packages`)
- Node 18+ and ffmpeg
- The Kokoro voice model. If `build.py` says it's missing, run `npx -y hyperframes@0.8.216 tts "hello" -o /tmp/warm.wav` once to download it.
- For QA screenshots and covers: Playwright with Chromium (`require('playwright')`).
- `gsap.min.js` (3.14.2). If it's missing, `build.py` fetches it with `npm pack`.

## Make a reel

1. Write `specs/NN_slug.json` (copy an existing spec). For a premium voice, record the whole script as one WAV (for example Gemini in Google AI Studio) and set `"voice_file": "voice/NN_slug.wav"`; the build lines up every word to the audio. Without it, the free Kokoro voice in `"voice"` reads each line. `lines` are spoken one by one: put numbers and times in words in `say`, and the digits in `show` for the captions. `beats` put a card on screen from a given line. `cta` is the last line. Each `at` is a word from the script (the item appears when that word is spoken), seconds after the card lands (`0.3`), or seconds after the previous timed item (`"+0.3"`).
2. Build: `python3 build.py specs/NN_slug.json` writes `../build/NN_slug/` (index.html, audio/mix.wav, meta.json).
3. Check: `python3 qa_all.py <screenshot_dir> NN` saves frames and flags any text that spills out of a card. Look at the frames.
4. Render: `./render.sh ../build/NN_slug` (about 90 seconds on 2 cores) gives `master.mp4`. Set `HYPERFRAMES_BROWSER_PATH` if Chromium lives somewhere else.
5. Package: `python3 post.py <out_dir> NN` writes `NN_slug.mp4` (under 9.6 MB), `NN_cover.jpg` and `NN_caption.txt`.

## Card types

`rows` (list with icons, chips, strike-throughs, progress bars, optional `hero` and `panel`), `big` (one or two big numbers), `meter` (credits draining, optional `stamp`), `slots` (a schedule grid with `flips`), `notif` (a phone notification or an empty inbox), `code` (light or dark terminal with typed lines and a `progress` bar), `grid` (tiles), `email`, `site` (a web page with a highlighted phrase), `chart` (fast, base and slow lines, or `mode: rewrite`), `chat` (message bubbles). The fields for each are in `build.py`.

## Style

Paper `#F3EFE6`, ink `#111827`, accent `#FF5A1F`, blue `#2563EB`. Fraunces for headlines, Archivo for text, JetBrains Mono for code (all under the SIL Open Font License). Keep text inside x 60 to 920 below y 1050 so Instagram's buttons don't cover it.
