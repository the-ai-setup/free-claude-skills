// Profile picture: the robot on paper, head centred for a round crop.  usage: node profile.js <out.png>
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const robot = fs.readFileSync(path.join(__dirname, 'robot.svg'), 'utf8');
(async () => {
  const b = await chromium.launch();
  const p = await b.newPage({ viewport: { width: 1080, height: 1080 } });
  await p.setContent(`<html><body style="margin:0;background:#F3EFE6">
    <div style="position:absolute;left:0;top:0;width:1080px;height:1080px;overflow:hidden;background:#F3EFE6;
      background-image:radial-gradient(rgba(17,24,39,.07) 2.2px,transparent 2.6px);background-size:40px 40px">
      <div style="position:absolute;left:190px;top:120px;width:700px;height:1050px">${robot.replace('<svg ', '<svg width="700" height="1050" ')}</div>
    </div></body></html>`);
  await p.screenshot({ path: process.argv[2] });
  await b.close();
})();
