import json, os, subprocess, sys, glob
from PIL import Image
Q = sys.argv[1]
B = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'build')
names = sorted(d for d in os.listdir(B) if os.path.exists(os.path.join(B, d, 'meta.json')))
if len(sys.argv) > 2: names = [n for n in names if n[:2] in sys.argv[2:]]
for n in names:
    m = json.load(open(os.path.join(B, n, 'meta.json')))
    tins, cta, T = m['cards_in'], m['cta_in'], m['total']
    outs = tins[1:] + [cta]
    ts = [0.05] + [round(o - 0.2, 2) for o in outs] + [round(T - 0.3, 2)]
    for f in glob.glob(f'{Q}/{n}_*.png'): os.remove(f)
    r = subprocess.run(['node', 'qa.js', os.path.join(B, n), f'{Q}/{n}'] + [str(t) for t in ts], capture_output=True, text=True, timeout=240)
    try:
        rep = json.loads(r.stdout[r.stdout.index('{'):])
    except Exception:
        print(n, 'QA FAILED', r.stdout[-300:], r.stderr[-300:]); continue
    print(n, 'errors:', rep['errors'][:2], 'issues:', rep['issues'][:6])
    fs = sorted(glob.glob(f'{Q}/{n}_*.png'), key=lambda p: float(p.rsplit('_', 1)[1][:-4]))
    W, H = 300, 533
    sheet = Image.new('RGB', (W * len(fs), H), 'white')
    for i, f in enumerate(fs):
        sheet.paste(Image.open(f).convert('RGB').resize((W, H)), (i * W, 0))
    sheet.save(f'{Q}/sheet_{n}.jpg', quality=82)
