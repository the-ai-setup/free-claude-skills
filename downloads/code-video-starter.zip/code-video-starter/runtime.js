(function () {
  window.__timelines = window.__timelines || {};
  var P = window.__PLAN;
  var T = P.total;
  var tl = gsap.timeline({ paused: true });
  function num(el, a, d) { var v = el.getAttribute(a); return v === null ? d : parseFloat(v); }
  function reps(span, cycle) { return Math.max(0, Math.floor(span / cycle) - 1); }
  function $(s) { return document.querySelector(s); }
  function $$(s) { return Array.prototype.slice.call(document.querySelectorAll(s)); }

  // ---------- background: glows breathe, ghost word drifts, grid creeps upward
  tl.fromTo(".glow.g1", { scale: 0.85, x: 0, opacity: 0 }, { scale: 1.12, x: -60, opacity: 1, duration: 2.4, ease: "sine.out" }, 0.05);
  tl.fromTo(".glow.g1", { scale: 1.12 }, { scale: 0.96, duration: 3.1, ease: "sine.inOut", yoyo: true, repeat: reps(T - 2.5, 3.1), immediateRender: false }, 2.45);
  tl.fromTo(".glow.g2", { scale: 0.9, y: 40, opacity: 0 }, { scale: 1.08, y: -30, opacity: 1, duration: 2.8, ease: "sine.out" }, 0.2);
  tl.fromTo(".glow.g2", { y: -30 }, { y: 50, duration: 3.7, ease: "sine.inOut", yoyo: true, repeat: reps(T - 3.0, 3.7), immediateRender: false }, 3.0);
  tl.fromTo(".ghost", { x: 140, opacity: 0 }, { x: -120, opacity: 1, duration: T, ease: "none" }, 0);
  tl.fromTo(".bg-dots", { backgroundPosition: "20px 20px" }, { backgroundPosition: "20px -140px", duration: T, ease: "none" }, 0);
  tl.fromTo(".meta .rule", { scaleX: 0 }, { scaleX: 1, duration: 0.9, ease: "power3.inOut" }, 0.1);
  tl.fromTo(".meta .m1", { x: -30, opacity: 0 }, { x: 0, opacity: 1, duration: 0.45, ease: "power3.out" }, 0.2);
  tl.fromTo(".meta .m2", { x: 30, opacity: 0 }, { x: 0, opacity: 1, duration: 0.5, ease: "expo.out" }, 0.3);
  $$(".tick").forEach(function (e, i) {
    tl.fromTo(e, { scale: 0, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.4, ease: "back.out(3)" }, 0.35 + i * 0.06);
  });

  // ---------- headline: words rise out of a mask, then the accent line wipes on and gets underlined
  tl.fromTo(".h1 .wi", { yPercent: 115, rotation: 7 }, { yPercent: 0, rotation: 0, duration: 0.6, ease: "expo.out", stagger: 0.07 }, 0.12);
  tl.fromTo(".h2t", { clipPath: "inset(0% 100% 0% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: 0.55, ease: "power3.inOut" }, 0.62);
  tl.fromTo(".h2 .u", { scaleX: 0 }, { scaleX: 1, duration: 0.45, ease: "power4.out" }, 1.05);

  // ---------- cards: velocity-matched transitions on the wrapper, slow tilt on the card itself
  var TR = {
    drop: { from: { y: -90, opacity: 0, scale: 0.94, rotationX: 0, filter: "blur(0px)" }, d: 0.7, e: "back.out(1.5)" },
    push: { from: { y: 190, opacity: 0, rotationX: -14, filter: "blur(12px)" }, out: { y: -190, opacity: 0, rotationX: 12, filter: "blur(12px)" }, d: 0.62, e: "power3.out" },
    whip: { from: { x: 460, opacity: 0, rotationY: -18, filter: "blur(16px)" }, out: { x: -460, opacity: 0, rotationY: 18, filter: "blur(16px)" }, d: 0.48, e: "power3.out" },
    zoom: { from: { scale: 0.74, opacity: 0, filter: "blur(14px)" }, out: { scale: 1.22, opacity: 0, filter: "blur(14px)" }, d: 0.6, e: "expo.out" }
  };
  var neutral = { x: 0, y: 0, scale: 1, rotationX: 0, rotationY: 0, opacity: 1, filter: "blur(0px)" };
  $$(".cardw").forEach(function (w) {
    var tin = num(w, "data-in", 0), tout = num(w, "data-out", null);
    var ti = TR[w.getAttribute("data-tr") || "push"], to = TR[w.getAttribute("data-trout") || "push"];
    tl.set(w, { transformPerspective: 1600 }, 0);
    var toVars = Object.assign({}, neutral, { duration: ti.d, ease: ti.e });
    tl.fromTo(w, Object.assign({}, neutral, ti.from), toVars, tin);
    if (tout !== null) {
      tl.fromTo(w, neutral, Object.assign({}, to.out, { duration: 0.3, ease: "power2.in", immediateRender: false }), tout);
      tl.set(w, { opacity: 0 }, tout + 0.31);
    }
    var card = w.querySelector(".card"), span = (tout === null ? T : tout) - tin;
    var dir = w.getAttribute("data-tilt") === "r" ? 1 : -1;
    tl.fromTo(card, { rotationY: -3 * dir, rotationX: 2, transformPerspective: 1600 },
      { rotationY: 3 * dir, rotationX: -1, duration: Math.max(0.5, span), ease: "sine.inOut" }, tin);
  });

  // ---------- items inside cards: every kind gets its own verb
  var FX = {
    up: function (e, t) { tl.fromTo(e, { opacity: 0, y: 40, rotationX: -35 }, { opacity: 1, y: 0, rotationX: 0, duration: 0.5, ease: "power4.out" }, t); },
    left: function (e, t) { tl.fromTo(e, { opacity: 0, x: -70 }, { opacity: 1, x: 0, duration: 0.5, ease: "power3.out" }, t); },
    right: function (e, t) { tl.fromTo(e, { opacity: 0, x: 70 }, { opacity: 1, x: 0, duration: 0.45, ease: "expo.out" }, t); },
    fade: function (e, t) { tl.fromTo(e, { opacity: 0 }, { opacity: 1, duration: 0.4, ease: "power1.out" }, t); },
    pop: function (e, t) { tl.fromTo(e, { opacity: 0, scale: 0.35, rotation: -10 }, { opacity: 1, scale: 1, rotation: 0, duration: 0.45, ease: "back.out(2.8)" }, t); },
    slam: function (e, t) { tl.fromTo(e, { opacity: 0, scale: 1.9 }, { opacity: 1, scale: 1, duration: 0.34, ease: "power4.out" }, t); },
    drop: function (e, t) { tl.fromTo(e, { opacity: 0, y: -70, scale: 0.95 }, { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: "bounce.out" }, t); },
    flip: function (e, t) { tl.fromTo(e, { opacity: 0, rotationY: 88, transformPerspective: 900 }, { opacity: 1, rotationY: 0, duration: 0.55, ease: "back.out(1.6)" }, t); },
    bubble: function (e, t) { tl.fromTo(e, { opacity: 0, y: 30, scale: 0.8 }, { opacity: 1, y: 0, scale: 1, duration: 0.42, ease: "back.out(2.2)" }, t); },
    strike: function (e, t) { tl.fromTo(e, { scaleX: 0 }, { scaleX: 1, duration: 0.3, ease: "power2.inOut" }, t); },
    fill: function (e, t) { tl.fromTo(e, { scaleX: 0 }, { scaleX: 1, duration: num(e, "data-dur", 0.9), ease: "expo.out" }, t); },
    type: function (e, t) {
      var n = num(e, "data-n", 20), d = Math.min(0.7, Math.max(0.2, n * 0.018));
      tl.fromTo(e, { clipPath: "inset(0% 100% 0% 0%)" }, { clipPath: "inset(0% 0% 0% 0%)", duration: d, ease: "steps(" + Math.max(4, Math.min(n, 40)) + ")" }, t);
    },
    mark: function (e, t) {
      tl.fromTo(e, { backgroundSize: "0% 100%" }, { backgroundSize: "100% 100%", duration: 0.35, ease: "power2.out" }, t);
      if (e.classList.contains("mk-bad")) tl.fromTo(e, { color: "#111827" }, { color: "#B91C1C", duration: 0.3, ease: "power1.out" }, t);
    },
    count: function (e, t) {
      var f = num(e, "data-from", 0), to = num(e, "data-to", 0), d = num(e, "data-dur", 0.8), st = e.getAttribute("data-steps");
      tl.fromTo(e, { textContent: f }, { textContent: to, duration: d, ease: st ? "steps(" + st + ")" : "power2.out", snap: { textContent: 1 } }, t);
    },
    stamp: function (e, t) {
      tl.fromTo(e, { opacity: 0, scale: 2.4, rotation: -28 }, { opacity: 1, scale: 1, rotation: -12, duration: 0.28, ease: "power4.in" }, t);
      tl.fromTo(".cam", { x: 0, y: 0 }, { keyframes: { x: [0, -9, 8, -5, 3, 0], y: [0, 6, -5, 3, -1, 0] }, duration: 0.32, ease: "none", immediateRender: false }, t + 0.27);
    },
    dim: function (e, t) { tl.fromTo(e, { backgroundColor: "#FF5A1F", scaleY: 1 }, { backgroundColor: "#E9E3D7", scaleY: 0.82, duration: 0.18, ease: "power2.out" }, t); },
    draw: function (e, t) {
      var L = e.getTotalLength(); e.style.strokeDasharray = L + " " + L;
      tl.fromTo(e, { opacity: 0 }, { opacity: 1, duration: 0.06 }, t);
      tl.fromTo(e, { strokeDashoffset: L }, { strokeDashoffset: 0, duration: num(e, "data-dur", 1.0), ease: "power2.inOut" }, t);
    },
    flipst: function (e, t) { tl.fromTo(e, { opacity: 0, rotationX: -90, transformPerspective: 700 }, { opacity: 1, rotationX: 0, duration: 0.42, ease: "back.out(2)" }, t); }
  };
  $$("[data-fx]").forEach(function (e) {
    var f = FX[e.getAttribute("data-fx")];
    if (f) f(e, num(e, "data-t", 0));
  });

  // a check icon inside a row draws itself when its chip lands
  $$(".ic path[data-draw]").forEach(function (p) { FX.draw(p, num(p, "data-t", 0)); });

  // ---------- captions: 2 to 3 words, karaoke colour + pop on the spoken word, hard kill at the end
  $$(".cg").forEach(function (g) {
    var a = num(g, "data-t0", 0), b = num(g, "data-t1", 0);
    tl.fromTo(g, { opacity: 0, y: 16, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.13, ease: "back.out(2.2)" }, a);
    g.querySelectorAll(".cw").forEach(function (w) {
      var t = Math.max(a, num(w, "data-t", a));
      if (w.classList.contains("kp")) {
        tl.fromTo(w, { backgroundColor: "rgba(255,90,31,0)", color: "#9AA1AD" }, { backgroundColor: "rgba(255,90,31,1)", color: "#FFFFFF", duration: 0.1, ease: "power2.out" }, t);
        tl.fromTo(w, { scale: 1 }, { scale: 1.16, duration: 0.12, ease: "power2.out", yoyo: true, repeat: 1 }, t);
      } else if (w.classList.contains("ka")) {
        tl.fromTo(w, { color: "#9AA1AD" }, { color: "#E8480F", duration: 0.08 }, t);
        tl.fromTo(w, { scale: 1 }, { scale: 1.1, duration: 0.1, ease: "power2.out", yoyo: true, repeat: 1 }, t);
      } else {
        tl.fromTo(w, { color: "#9AA1AD" }, { color: "#111827", duration: 0.08 }, t);
        tl.fromTo(w, { y: 0 }, { y: -5, duration: 0.09, ease: "power2.out", yoyo: true, repeat: 1 }, t);
      }
    });
    tl.set(g, { opacity: 0 }, b);
  });

  // ---------- keyword sticky note: swings in on its pin, sways, leaves before the CTA
  var kw = $(".kwtag");
  if (kw) {
    var k0 = num(kw, "data-t0", 2), k1 = num(kw, "data-t1", T);
    tl.fromTo(kw, { opacity: 0, rotation: -40, scale: 0.6 }, { opacity: 1, rotation: -4, scale: 1, duration: 0.8, ease: "elastic.out(1, 0.45)" }, k0);
    var sway = reps(k1 - k0 - 0.9, 1.3);
    if (sway >= 1) tl.fromTo(kw, { rotation: -4 }, { rotation: 3, duration: 1.3, ease: "sine.inOut", yoyo: true, repeat: sway, immediateRender: false }, k0 + 0.85);
    tl.fromTo(kw, { opacity: 1, scale: 1 }, { opacity: 0, scale: 0.6, rotation: 12, duration: 0.25, ease: "power2.in", immediateRender: false }, k1);
  }

  // ---------- CTA: pill slams, lines burst, confetti flies, the pill breathes
  var cta = P.cta;
  $$(".cta-pill").forEach(function (e) {
    var t = num(e, "data-t", 0) + 0.7;
    tl.fromTo(e, { scale: 1 }, { scale: 1.05, duration: 0.5, ease: "sine.inOut", yoyo: true, repeat: reps(T - t, 0.5), immediateRender: false }, t);
  });
  if (cta) {
    tl.fromTo(".burst i", { scaleY: 0, opacity: 1 }, { scaleY: 1, duration: 0.3, ease: "expo.out", stagger: 0.012 }, cta.hit);
    tl.to(".burst i", { opacity: 0, duration: 0.35, ease: "power1.in" }, cta.hit + 0.32);
    P.confetti.forEach(function (c, i) {
      var el = document.getElementById("cf" + i);
      tl.fromTo(el, { x: 0, y: 0, rotation: 0, scale: 0, opacity: 1 },
        { keyframes: { x: [0, c.dx * 0.65, c.dx], y: [0, c.up, c.fall], rotation: [0, c.r * 0.5, c.r], scale: [0, 1, 1] },
          duration: c.d, ease: "none" }, cta.hit + c.delay);
      tl.to(el, { opacity: 0, duration: 0.3, ease: "power1.in" }, cta.hit + c.delay + c.d - 0.3);
    });
    tl.fromTo(".flash", { opacity: 0 }, { keyframes: { opacity: [0, 0.3, 0] }, duration: 0.26, ease: "none" }, cta.in);
  }

  // ---------- robot: rises in, waves, taps the card on each beat, celebrates at the CTA
  var R = P.robot;
  tl.fromTo("#robotWrap", { y: 420, opacity: 0 }, { y: 0, opacity: 1, duration: 0.8, ease: "back.out(1.3)" }, 0.05);
  tl.fromTo(".shadow", { scaleX: 0.3, opacity: 0 }, { scaleX: 1, opacity: 1, duration: 0.8, ease: "power2.out" }, 0.05);
  tl.set("#mouth", { transformOrigin: "50% 50%", scaleY: R.mouth[0] }, 0);
  tl.to("#mouth", { keyframes: { scaleY: R.mouth, easeEach: "none" }, duration: (R.mouth.length - 1) / R.fps, ease: "none" }, 0);
  tl.set("#eyes", { transformOrigin: "50% 50%" }, 0);
  R.blinks.forEach(function (t) {
    tl.fromTo("#eyes", { scaleY: 1 }, { scaleY: 0.1, duration: 0.07, ease: "power1.in", yoyo: true, repeat: 1, immediateRender: false }, t);
  });
  tl.set("#armR", { svgOrigin: "392 508" }, 0);
  tl.set("#armL", { svgOrigin: "130 508" }, 0);
  tl.set("#bulb", { transformOrigin: "50% 50%" }, 0);
  // wave hello
  tl.fromTo("#armR", { rotation: 0 }, { rotation: -22, duration: 0.18, ease: "sine.inOut", yoyo: true, repeat: 5 }, 0.55);
  R.taps.forEach(function (t) {
    tl.fromTo("#armR", { rotation: 0 }, { rotation: -16, duration: 0.17, ease: "power2.out", yoyo: true, repeat: 1, immediateRender: false }, t);
    tl.fromTo("#pupils", { x: 0, y: 0 }, { x: 7, y: -9, duration: 0.18, ease: "power2.out", yoyo: true, repeat: 1, repeatDelay: 0.6, immediateRender: false }, t);
    tl.fromTo("#bulb", { scale: 1 }, { scale: 1.5, duration: 0.14, ease: "power2.out", yoyo: true, repeat: 1, immediateRender: false }, t);
  });
  R.nods.forEach(function (t) {
    tl.fromTo("#robotBob", { rotation: 0 }, { rotation: 2.5, duration: 0.14, ease: "power2.out", yoyo: true, repeat: 1, immediateRender: false }, t);
  });
  // idle float on the inner wrapper so the jump on the outer wrapper never fights it
  tl.fromTo("#robotBob", { y: 0 }, { y: -12, duration: 1.5, ease: "sine.inOut", yoyo: true, repeat: reps(T - 0.9, 1.5) }, 0.9);
  tl.set("#head", { svgOrigin: "260 410" }, 0);
  tl.fromTo("#head", { rotation: -2.5 }, { rotation: 2.5, duration: 2.2, ease: "sine.inOut", yoyo: true, repeat: reps(T, 2.2) }, 0);
  if (cta) {
    var j = cta.hit;
    tl.fromTo("#robotWrap", { y: 0, scaleY: 1, scaleX: 1, transformOrigin: "50% 100%" },
      { keyframes: { y: [0, 14, -70, 0, 0], scaleY: [1, 0.9, 1.06, 0.92, 1], scaleX: [1, 1.07, 0.96, 1.06, 1] }, duration: 0.7, ease: "none", immediateRender: false }, j - 0.12);
    tl.fromTo(".shadow", { scaleX: 1 }, { keyframes: { scaleX: [1, 1.1, 0.6, 1.1, 1] }, duration: 0.7, ease: "none", immediateRender: false }, j - 0.12);
    tl.fromTo("#armL", { rotation: 0 }, { rotation: 138, duration: 0.35, ease: "back.out(2)", immediateRender: false }, j);
    tl.fromTo("#pupils", { opacity: 1 }, { opacity: 0, duration: 0.08, immediateRender: false }, j + 0.05);
    tl.fromTo("#happy", { opacity: 0, scaleY: 0.4, transformOrigin: "50% 50%" }, { opacity: 1, scaleY: 1, duration: 0.18, ease: "back.out(3)" }, j + 0.05);
    tl.fromTo(".blush", { opacity: 0.32 }, { opacity: 0.85, duration: 0.25, ease: "power2.out", immediateRender: false }, j + 0.05);
  }

  window.__timelines["main"] = tl;
})();
