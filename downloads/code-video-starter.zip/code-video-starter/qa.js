// QA: screenshot a built reel at given times and flag text that overflows its card.
// usage: node qa.js <build_dir> <out_png_prefix> t1 t2 ...   (serves the folder on a local port)
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');

const dir = path.resolve(process.argv[2]);
const outPrefix = process.argv[3];
const times = process.argv.slice(4).map(Number);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.woff2': 'font/woff2', '.wav': 'audio/wav', '.svg': 'image/svg+xml' };

const server = http.createServer((req, res) => {
  const p = path.join(dir, decodeURIComponent(req.url.split('?')[0]));
  if (!p.startsWith(dir) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': types[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});

server.listen(0, async () => {
  const port = server.address().port;
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 } });
  const errors = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto(`http://127.0.0.1:${port}/index.html`);
  await page.waitForFunction(() => !!(window.__timelines && window.__timelines.main));
  await page.evaluate(() => document.fonts.ready);
  const report = [];
  for (const t of times) {
    const issues = await page.evaluate((t) => {
      window.__timelines.main.seek(t, false);
      const out = [];
      const head = document.querySelector('.head').getBoundingClientRect();
      if (head.bottom > 548) out.push(`headline bottom ${Math.round(head.bottom)} > 548`);
      document.querySelectorAll('.cardw').forEach(c => {
        if (parseFloat(getComputedStyle(c).opacity) < 0.9) return;
        const cr = c.getBoundingClientRect();
        c.querySelectorAll('.lb,.chip,.sb,.tl,.ts,.ln,.hd,.tx2,.px,.bub,.cta-pill,.cta-sub,h3,.ss,.v,.l,.f,p,.e1,.e2,.snote,.bnote,.rl,.st span,.url').forEach(e => {
          const r = e.getBoundingClientRect();
          if (r.width === 0) return;
          if (r.right > cr.right - 8 || r.bottom > cr.bottom - 4 || r.left < cr.left + 4) {
            out.push(`overflow in "${c.querySelector('.ttl').textContent}": <${e.className || e.tagName}> "${e.textContent.trim().slice(0, 40)}" r=${Math.round(r.right)}/${Math.round(cr.right)} b=${Math.round(r.bottom)}/${Math.round(cr.bottom)}`);
          }
        });
      });
      document.querySelectorAll('.cg').forEach(e => {
        if (parseFloat(getComputedStyle(e).opacity) < 0.5) return;
        const r = e.getBoundingClientRect();
        if (r.height > 130) out.push(`caption wraps to ${Math.round(r.height)}px: "${e.textContent}"`);
      });
      return out;
    }, t);
    await page.waitForTimeout(60);
    await page.screenshot({ path: `${outPrefix}_${t.toFixed(2)}.png` });
    issues.forEach(i => report.push(`t=${t}: ${i}`));
  }
  console.log(JSON.stringify({ errors, issues: [...new Set(report)] }, null, 1));
  await browser.close();
  server.close();
});
