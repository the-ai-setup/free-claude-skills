// Cover image for a reel: the first card fully built, headline moved down so it survives the 3:4 grid crop.
// usage: node cover.js <build_dir> <out.jpg> <time>
const { chromium } = require('playwright');
const http = require('http');
const fs = require('fs');
const path = require('path');

const dir = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
const t = Number(process.argv[4]);
const types = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.woff2': 'font/woff2', '.wav': 'audio/wav' };

const server = http.createServer((req, res) => {
  const p = path.join(dir, decodeURIComponent(req.url.split('?')[0]));
  if (!p.startsWith(dir) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { res.writeHead(404); return res.end(); }
  res.writeHead(200, { 'Content-Type': types[path.extname(p)] || 'application/octet-stream' });
  fs.createReadStream(p).pipe(res);
});

server.listen(0, async () => {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1080, height: 1920 } });
  await page.goto(`http://127.0.0.1:${server.address().port}/index.html`);
  await page.waitForFunction(() => !!(window.__timelines && window.__timelines.main));
  await page.evaluate(() => document.fonts.ready);
  await page.evaluate((t) => {
    window.__timelines.main.seek(t, false);
    const s = document.createElement('style');
    s.textContent = '.head{top:300px!important}.stage{top:650px!important}.caps,.kwtag{display:none!important}' +
      '#robotWrap{top:1250px!important}.shadow{top:1844px!important}';
    document.head.appendChild(s);
  }, t);
  await page.waitForTimeout(120);
  await page.screenshot({ path: out, type: 'jpeg', quality: 90 });
  await browser.close();
  server.close();
  console.log('cover', out);
});
