---
name: brain-dump-to-plan
description: Turn a messy brain dump (a voice note transcript, a pasted list, scattered thoughts) into a realistic plan for the week. Use when the user pastes unstructured thoughts, says "brain dump", "help me plan my week" or "I have too much on", or asks what to focus on.
---

# Brain dump to plan

The user has emptied their head onto the page. Sort it into a week they can finish, not a wish list.

## Steps

1. Pull out each task, worry and idea. Rewrite each one as a short action that starts with a verb ("Email the landlord", not "landlord stuff").
2. Sort them:
   - Must do this week: there's a deadline, someone is waiting, or money depends on it.
   - Should do: moves a goal forward, but nothing breaks if it slips.
   - Not this week: ideas and nice-to-haves. Park them.
3. Ask one question only if you can't plan without the answer, such as how many hours they have. Otherwise assume about two focused hours a day on weekdays and say so.
4. Build the week. No more than three tasks on a day. Hardest task first. Leave Friday afternoon free to catch up.
5. Pick the one task that would make the week a success if it were the only thing done, and put it at the top.

## Output

**The one thing:** [task]

| Day | Tasks |
| --- | --- |
| Mon | ... |
| Tue | ... |
| Wed | ... |
| Thu | ... |
| Fri | ... (afternoon free) |

**Parked for later:** the "not this week" items.

**First step today:** one action that takes under 15 minutes.

Keep it plain. No motivational lines.
