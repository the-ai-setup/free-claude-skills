---
name: idea-ledger
description: Run a credit ledger for business, content or side-project ideas so weak ideas get archived by simple maths instead of hope. Each idea starts with 14 credits, loses 1 a day, earns 3 per real reply, 7 per booked call and 1 per 100 pounds earned, and is archived at zero. Use when the user is testing ideas, asks "is this working" or "should I keep going with this", or wants to update their ideas ledger.
---

# Idea ledger

Each idea is on a clock, and it has to earn its time with real signals.

## The rules

- New idea: 14 credits. The clock starts on the day the first real attempt goes out (first email, first post, first ad), not the day the idea arrives.
- Each day: minus 1.
- A real reply from a person: plus 3.
- A booked call or meeting: plus 7.
- Each £100 earned: plus 1.
- Opens, clicks, likes, views and follows: 0.
- At 0 the idea is archived. To try again, change the message or the audience and start a new 14-day ledger.

## Where the ledger lives

- If you can read and write files (Cowork or Claude Code), keep `ideas-ledger.md` in the user's folder and update it there.
- In a normal chat, ask the user to paste their current ledger, update it, and give it back for them to save.

## The table

| Idea | Started | Credits | Replies | Calls | £ | Status |
| --- | --- | --- | --- | --- | --- | --- |

Status: live (8 or more), warning (4 to 7), last chance (1 to 3), archived (0).

## Each update

1. Take off the days since the last update.
2. Add credits for replies, calls and money since then.
3. Update the status.
4. For each idea under 4, say in one line what single result would save it ("one reply by Friday").
5. For an idea over 21, suggest testing the same offer on a new audience as a separate idea.

Report archived and last-chance ideas first, then the healthy ones. Judge from the numbers in the table, not from how good the idea sounds.
