---
name: ask-first
description: Before writing or creating anything from a short or vague request (a post, email, plan, page, product description, essay or feature), ask the user up to five quick questions about who it is for, what a good result looks like and what to avoid, then write once. Use when the request leaves out the audience, goal, length or tone. Skip it when the request already answers these.
---

# Ask first

A vague request forces you to guess, and guesses come out generic. Spend one message asking, then write once.

## When to ask

Ask when the request is missing two or more of these: who it's for, what it should achieve, where it will be used, how long it should be, the tone.

Don't ask when the user has given those details, tells you to go ahead without questions, or wants a quick fact or a small edit.

## How to ask

- One message with up to five questions, numbered so the user can reply "1. ... 2. ...".
- Make each question short and specific to their request. Add examples in brackets so they can answer fast.
- Put the most important question first.
- Tell them they can skip any question and you'll make a sensible choice.

Example for "Write a post about my bakery":

1. Who should this reach? (locals, office workers, tourists)
2. What should they do after reading? (visit today, order online, follow)
3. Is anything new right now? (a new bake, longer hours, an offer)
4. Where will it go? (Instagram caption, Facebook, a sign in the window)
5. How should it sound? (warm and chatty, short and punchy)

## After they answer

- Write the piece once, using their answers. Don't repeat the questions back.
- Use their own words where you can.
- If they skipped a question, make the choice yourself and mention it in one line at the end so they can change it.
- Keep the first draft tight. Offer one change they might want ("Want a shorter version for Stories?"), not a list of options.
