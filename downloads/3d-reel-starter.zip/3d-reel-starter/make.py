#!/usr/bin/env python3
"""3D reel starter: turn a JSON script into a 3D reel project for the free HyperFrames renderer.
    python3 make.py examples/01_made_with_claude.json      -> out/skit_01_made_with_claude/
    ./render.sh out/skit_01_made_with_claude                -> master.mp4
The scene, the presenter and the robot live in skit3d.js (Three.js). Each scene in the JSON picks a camera
shot, a pose and face for the presenter, what the robot does and what the monitor shows. See README.md."""
import html as H
import json
import os
import shutil
import subprocess
import sys
import tempfile

import numpy as np
import soundfile as sf

HERE = os.path.dirname(os.path.abspath(__file__))
SR = 24000
FPS = 30
# "look" in the JSON swaps these colours in skit3d.js (hex, e.g. "hoodie": "#2E7D32")
LOOK = {
    "skin": ["0xD49A72", "0xCF9269", "0xC98762"],
    "beard": ["0x2A1B14"],
    "hair": ["0x24170F"],
    "beanie": ["0xEEE8DC", "0xE9E2D4"],
    "accent": ["0xFF5A1F"],
    "hoodie": ["0x34466A"],
    "hoodie_dark": ["0x253250"],
}


def vendor():
    """Fetch Three.js and GSAP from npm once (both free to use) into vendor/."""
    vd = os.path.join(HERE, 'vendor')
    os.makedirs(vd, exist_ok=True)
    for pkg, src, dst in (('three@0.170.0', 'package/build/three.module.min.js', 'three.module.min.js'),
                          ('gsap@3.14.2', 'package/dist/gsap.min.js', 'gsap.min.js')):
        if os.path.exists(os.path.join(vd, dst)):
            continue
        tmp = tempfile.mkdtemp()
        subprocess.run(['npm', 'pack', pkg, '--silent'], cwd=tmp, check=True, stdout=subprocess.DEVNULL)
        tgz = [f for f in os.listdir(tmp) if f.endswith('.tgz')][0]
        subprocess.run(['tar', 'xzf', tgz], cwd=tmp, check=True)
        shutil.copy(os.path.join(tmp, src), os.path.join(vd, dst))


def fit_size(text, ttf, max_w, max_size, tracking=0.0):
    path = os.path.join(HERE, 'ttf', ttf)
    try:
        from PIL import ImageFont
        ImageFont.truetype(path, 10)
    except Exception:
        return int(min(max_size, max_w / (0.72 * max(1, len(text)))))
    from PIL import ImageFont
    size = max_size
    while size > 20:
        f = ImageFont.truetype(path, size)
        if f.getlength(text) + tracking * size * len(text) <= max_w:
            return size
        size -= 1
    return size


# ---------------------------------------------------------------- audio


def music(T, seed, bpm=96):
    rng = np.random.default_rng(seed)
    n = int(T * SR)
    t = np.arange(n) / SR
    beat = 60.0 / bpm
    progs = [
        [[48, 52, 55, 59], [45, 52, 55, 60], [41, 53, 57, 60], [43, 55, 59, 62]],
        [[45, 52, 57, 60], [41, 53, 57, 60], [48, 52, 55, 59], [43, 50, 55, 59]],
        [[41, 53, 57, 64], [43, 55, 59, 62], [45, 52, 57, 60], [48, 52, 55, 59]],
    ]
    prog = progs[seed % len(progs)]
    f = lambda m: 440.0 * 2 ** ((m - 69) / 12.0)
    out = np.zeros(n, dtype=np.float64)
    bar = beat * 4
    span = bar * 2
    k = 0
    while k * span < T + span:
        ch = prog[k % len(prog)]
        s0 = k * span
        a, z = int(max(0, s0 - 0.3) * SR), int(min(T, s0 + span + 0.6) * SR)
        if a >= n:
            break
        tt = t[a:z] - s0
        env = np.clip((tt + 0.3) / 0.7, 0, 1) * np.clip((span + 0.6 - tt) / 0.9, 0, 1)
        for m in ch:
            for det in (-0.06, 0.0, 0.07):
                fr = f(m) * 2 ** (det / 12)
                ph = rng.uniform(0, 6.28)
                w = np.sin(2 * np.pi * fr * tt + ph) + 0.28 * np.sin(4 * np.pi * fr * tt + ph) + 0.1 * np.sin(6 * np.pi * fr * tt)
                out[a:z] += 0.035 * env * w
        # bass with a harmonic so phones can hear it
        root = f(ch[0] - 12)
        out[a:z] += 0.05 * env * (np.sin(2 * np.pi * root * tt) + 0.5 * np.sin(4 * np.pi * root * tt))
        # pluck arpeggio, eighth notes
        steps = int(span / (beat / 2))
        pattern = [0, 1, 2, 3, 2, 1, 2, 3]
        for s in range(steps):
            ts = s0 + s * beat / 2
            if ts >= T:
                break
            note = ch[pattern[s % 8]] + 12
            a2, z2 = int(ts * SR), min(n, int((ts + 0.6) * SR))
            if a2 >= n:
                break
            t2 = t[a2:z2] - ts
            vel = 0.075 * (0.8 + 0.4 * rng.random()) * (1.15 if s % 4 == 0 else 1.0)
            out[a2:z2] += vel * np.exp(-t2 / 0.16) * (np.sin(2 * np.pi * f(note) * t2) + 0.25 * np.sin(4 * np.pi * f(note) * t2))
        k += 1
    # soft off-beat hat
    for s in range(int(T / beat)):
        ts = s * beat + beat / 2
        a2 = int(ts * SR)
        z2 = min(n, a2 + int(0.035 * SR))
        if a2 >= n:
            break
        nz = rng.standard_normal(z2 - a2)
        nz = np.diff(np.concatenate([[0], nz]))
        out[a2:z2] += 0.018 * nz * np.exp(-np.arange(z2 - a2) / (0.008 * SR))
    fade_in = np.clip(t / 0.6, 0, 1)
    fade_out = np.clip((T - t) / 1.2, 0, 1)
    out *= fade_in * fade_out
    return out / (np.max(np.abs(out)) + 1e-9)


def sfx_sound(kind, rng):
    if kind == 'tick':
        d = 0.05
        tt = np.arange(int(d * SR)) / SR
        return 0.16 * np.exp(-tt / 0.012) * (np.sin(2 * np.pi * 1850 * tt) + 0.35 * np.sin(2 * np.pi * 3700 * tt))
    if kind == 'ping':
        d = 0.35
        tt = np.arange(int(d * SR)) / SR
        return 0.13 * np.exp(-tt / 0.09) * (np.sin(2 * np.pi * 1320 * tt) + 0.5 * np.sin(2 * np.pi * 1980 * tt))
    if kind == 'pop':
        d = 0.12
        tt = np.arange(int(d * SR)) / SR
        fr = 820 * np.exp(-tt / 0.05) + 260
        return 0.32 * np.exp(-tt / 0.04) * np.sin(2 * np.pi * np.cumsum(fr) / SR)
    if kind == 'stamp':
        d = 0.22
        tt = np.arange(int(d * SR)) / SR
        thump = np.sin(2 * np.pi * (140 * np.exp(-tt / 0.06) + 55) * tt) * np.exp(-tt / 0.06)
        click = rng.standard_normal(len(tt)) * np.exp(-tt / 0.006)
        return 0.42 * thump + 0.08 * click
    # swish / whoosh: filtered noise
    d = 0.18 if kind == 'swish' else 0.34
    m = int(d * SR)
    nz = rng.standard_normal(m)
    spec = np.fft.rfft(nz)
    fq = np.fft.rfftfreq(m, 1 / SR)
    centre, width = (3200, 1800) if kind == 'swish' else (1400, 1100)
    spec *= np.exp(-((fq - centre) / width) ** 2)
    nz = np.fft.irfft(spec, m)
    nz /= np.max(np.abs(nz)) + 1e-9
    tt = np.arange(m) / SR
    env = np.sin(np.pi * tt / d) ** 2
    return (0.05 if kind == 'swish' else 0.11) * nz * env


def esc(s):
    return H.escape(str(s), quote=True)


def words(line):
    return ' '.join(f'<span class="w">{esc(w)}</span>' for w in line.split())


def mix_audio(T, sfx, seed):
    n = int(T * SR)
    mus = music(T, seed, bpm=100) * 0.34
    fade = np.ones(n)
    fi, fo = int(0.25 * SR), int(0.9 * SR)
    fade[:fi] = np.linspace(0, 1, fi)
    fade[-fo:] = np.linspace(1, 0, fo)
    out = mus[:n] * fade
    rng = np.random.default_rng(seed + 7)
    for t, kind in sorted(sfx):
        if 0 <= t < T:
            s = sfx_sound(kind, rng) * (1.6 if kind in ('pop', 'swish') else 1.2)
            a = int(t * SR)
            z = min(n, a + len(s))
            out[a:z] += s[:z - a]
    peak = np.max(np.abs(out))
    if peak > 0.97:
        out *= 0.97 / peak
    return out.astype(np.float32)


def build(spec_path):
    spec = json.load(open(spec_path))
    n, slug = spec['n'], spec['slug']
    name = f'skit_{n:02d}_{slug}'
    out = os.path.join(HERE, 'out', name)
    os.makedirs(os.path.join(out, 'audio'), exist_ok=True)

    scenes, t = [], 0.0
    for s in spec['scenes'] + [dict(spec['cta'], cta=True)]:
        d = float(s['dur'])
        scenes.append(dict(s, t0=round(t, 3), t1=round(t + d, 3)))
        t += d
    T = round(t, 3)

    heads, sfx = [], []
    for i, s in enumerate(scenes):
        l1, l2 = s['head']
        f1 = fit_size(l1.upper(), 'montserrat-latin-900-normal.ttf', 860, s.get('size1', 92), -0.01)
        f2 = fit_size(l2.upper(), 'montserrat-latin-900-normal.ttf', 860, s.get('size2', 128 if s.get('stamp') else 108), -0.01)
        cls = 'hd stamp' if s.get('stamp') else 'hd'
        heads.append(f'<div class="{cls}" id="h{i}"><div class="l1" style="font-size:{f1}px">{words(l1)}</div>'
                     f'<div class="l2" style="font-size:{f2}px">{words(l2)}</div></div>')
        if i:
            sfx.append((s['t0'], 'swish'))
        sfx.append((s['t0'] + 0.08, 'pop'))
        if s.get('stamp'):
            sfx.append((s['t0'] + 0.42, 'stamp'))
        sc = s.get('screen') or {}
        if sc.get('type') == 'chat':
            q = sc.get('text', 'make me a 3D reel')
            for k in range(0, len(q), 3):
                sfx.append((s['t0'] + k / 22, 'tick'))
            sfx.append((s['t0'] + len(q) / 22 + 1.1, 'ping'))
        if s.get('fx') == 'wire':
            sfx.append((s['t0'] + s.get('fxAt', 0.4), 'whoosh'))
        if s.get('bot', {}).get('act') == 'pop':
            sfx.append((s['t0'] + s['bot'].get('at', 0.3), 'pop'))
    cta = scenes[-1]
    kw = spec['keyword']
    sfx += [(cta['t0'] + 0.75, 'pop'), (cta['t0'] + 1.5, 'tick'), (cta['t0'] + 1.62, 'tick'), (cta['t0'] + 1.9, 'ping')]

    plan = {'total': T, 'scenes': [{k: v for k, v in s.items() if k not in ('head',)} for s in scenes]}
    js3d = open(os.path.join(HERE, 'skit3d.js')).read()
    for part, new in (spec.get('look') or {}).items():
        for old in LOOK.get(part, []):
            js3d = js3d.replace(old, '0x' + new.lstrip('#').upper())
    open(os.path.join(out, 'skit3d.js'), 'w').write(js3d)
    vendor()
    for f in ('three.module.min.js', 'gsap.min.js'):
        shutil.copy(os.path.join(HERE, 'vendor', f), out)
    if os.path.isdir(os.path.join(out, 'fonts')):
        shutil.rmtree(os.path.join(out, 'fonts'))
    shutil.copytree(os.path.join(HERE, 'fonts'), os.path.join(out, 'fonts'))

    css = """
@font-face{font-family:"Montserrat";font-weight:900;src:url(fonts/montserrat-latin-900-normal.woff2) format("woff2")}
@font-face{font-family:"Archivo";font-weight:600;src:url(fonts/archivo-latin-700-normal.woff2) format("woff2")}
@font-face{font-family:"Archivo";font-weight:700;src:url(fonts/archivo-latin-800-normal.woff2) format("woff2")}
@font-face{font-family:"Archivo";font-weight:900;src:url(fonts/archivo-latin-900-normal.woff2) format("woff2")}
@font-face{font-family:"JetBrains Mono";font-weight:600;src:url(fonts/jetbrains-mono-latin-700-normal.woff2) format("woff2")}
html,body{margin:0;background:#0b1120}
#root{position:relative;width:1080px;height:1920px;overflow:hidden;background:#0b1120;font-family:"Archivo",sans-serif}
#skit3d{position:absolute;left:0;top:0;width:1080px;height:1920px;display:block}
.topfade{position:absolute;left:0;top:0;width:1080px;height:700px;background:linear-gradient(180deg,rgba(6,10,22,.88) 0%,rgba(6,10,22,.6) 50%,rgba(6,10,22,0) 100%)}
.vig{position:absolute;inset:0;background:radial-gradient(ellipse at 50% 58%,rgba(0,0,0,0) 58%,rgba(4,7,16,.6) 100%)}
.hd{position:absolute;left:60px;top:236px;width:960px;text-align:center;font-family:"Montserrat";font-weight:900;text-transform:uppercase;line-height:1.02;letter-spacing:-.01em;opacity:0}
.hd .l1{white-space:nowrap;color:#fff;text-shadow:0 6px 28px rgba(0,0,0,.65)}
.hd .l2{white-space:nowrap;color:#FF7A1A;margin-top:6px;text-shadow:0 6px 28px rgba(0,0,0,.65)}
.hd.stamp .l2{color:#3BE07A}
.w{display:inline-block;margin:0 .05em}
.ctab{position:absolute;left:90px;top:1290px;width:900px;opacity:0}
.bar{display:flex;align-items:center;gap:22px;height:118px;border-radius:60px;background:rgba(18,24,40,.92);border:3px solid rgba(255,255,255,.18);padding:0 26px;box-sizing:border-box;box-shadow:0 18px 50px rgba(0,0,0,.5)}
.bar .av{width:72px;height:72px;border-radius:50%;background:#FF7A1A;flex:none}
.bar .in{flex:1;font-weight:700;font-size:44px;color:rgba(255,255,255,.55)}
.bar .in b{color:#fff}
.bar .send{flex:none;width:84px;height:84px;border-radius:50%;background:#2F7DFF;display:flex;align-items:center;justify-content:center}
.sub{margin-top:26px;text-align:center;font-weight:700;font-size:40px;color:#e8edf8;text-shadow:0 4px 18px rgba(0,0,0,.7)}
.ld{position:absolute;opacity:0;font-family:"JetBrains Mono";font-weight:600}
.ld2{position:absolute;opacity:0;font-family:"Archivo";font-weight:900}
"""
    heads_js = []
    for i, s in enumerate(scenes):
        heads_js.append(f'tl.set("#h{i}",{{opacity:1}},{s["t0"]});')
        heads_js.append(f'tl.fromTo("#h{i} .w",{{y:46,scale:.82,opacity:0}},{{y:0,scale:1,opacity:1,duration:.32,ease:"back.out(2.2)",stagger:.07}},{s["t0"] + 0.05});')
        if s.get('stamp'):
            heads_js.append(f'tl.fromTo("#h{i} .l2",{{scale:1.9}},{{scale:1,duration:.34,ease:"power4.out"}},{s["t0"] + 0.36});')
        if i < len(scenes) - 1:
            heads_js.append(f'tl.to("#h{i}",{{opacity:0,duration:.08,ease:"none"}},{s["t1"] - 0.08});')
    c0 = cta['t0']
    heads_js += [
        f'tl.fromTo(".ctab",{{opacity:0,y:60}},{{opacity:1,y:0,duration:.45,ease:"back.out(1.8)"}},{c0 + 0.7});',
        f'tl.set(".bar .in",{{innerHTML:"Add a comment..."}},{c0 + 0.7});',
        f'tl.set(".bar .in",{{innerHTML:"<b>{esc(kw[:1])}</b>"}},{c0 + 1.5});',
        f'tl.set(".bar .in",{{innerHTML:"<b>{esc(kw)}</b>"}},{c0 + 1.62});',
        f'tl.fromTo(".bar .send",{{scale:1}},{{scale:1.25,duration:.16,ease:"power2.out",yoyo:true,repeat:1}},{c0 + 1.9});',
    ]
    doc = f'''<!doctype html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=1080, height=1920">
<title>{esc(name)}</title>
<style>{css}</style>
<script src="gsap.min.js"></script>
</head>
<body>
<div id="root" data-composition-id="main" data-width="1080" data-height="1920" data-start="0" data-duration="{T}" data-fps="{FPS}">
<canvas id="skit3d"></canvas>
<div class="topfade"></div>
<div class="vig"></div>
{chr(10).join(heads)}
<div class="ctab"><div class="bar"><div class="av"></div><div class="in">Add a comment...</div><div class="send"><svg viewBox="0 0 24 24" width="44" height="44"><path d="M3 11 L21 3 L13 21 L11 13 Z" fill="#fff"/></svg></div></div>
<div class="sub">{esc(cta.get("sub", "and I'll send it to you, free"))}</div></div>
<div class="ld">0</div><div class="ld2">0</div>
<audio id="mix" data-start="0" data-duration="{T}" data-track-index="5" src="audio/mix.wav" data-volume="1"></audio>
<script>window.__SKIT = {json.dumps(plan, separators=(',', ':'))};</script>
<script>
window.__timelines = window.__timelines || {{}};
var tl = gsap.timeline({{ paused: true }});
{chr(10).join(heads_js)}
window.__timelines["main"] = tl;
</script>
<script type="module" src="skit3d.js"></script>
</div>
</body>
</html>
'''
    open(os.path.join(out, 'index.html'), 'w').write(doc)
    sf.write(os.path.join(out, 'audio', 'mix.wav'), mix_audio(T, sfx, n), SR)
    json.dump({'name': name, 'total': T, 'keyword': kw, 'scenes': [{'t0': s['t0'], 't1': s['t1'], 'head': s['head']} for s in scenes],
               'caption': spec.get('caption', [])}, open(os.path.join(out, 'meta.json'), 'w'), indent=1)
    print(f'{name}: {T}s, {len(scenes)} scenes')
    return out


if __name__ == '__main__':
    for p in sys.argv[1:]:
        build(p)
