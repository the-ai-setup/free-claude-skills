// 3D story skit: the bearded guy at his desk with a monitor and a small robot sidekick, full frame.
// Driven by HyperFrames "hf-seek": every frame is rendered from its exact time, so renders are repeatable.
import * as THREE from './three.module.min.js';

const SK = window.__SKIT, T = SK.total, SCENES = SK.scenes;
const canvas = document.getElementById('skit3d');
const W = 1080, H = 1920;
const Q = Object.assign({ dpr: 0.68, aa: true, shadow: 'none' }, window.__P3D_Q || {});

// ---------- helpers
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const mix = (a, b, t) => a + (b - a) * t;
const sstep = (e0, e1, x) => { const t = clamp((x - e0) / (e1 - e0)); return t * t * (3 - 2 * t); };
const backOut = (t, s = 1.4) => { t = clamp(t); const u = t - 1; return 1 + (s + 1) * u * u * u + s * u * u; };
const pulse = (t, t0, up, hold, down) => {
  const u = t - t0;
  if (u <= 0) return 0;
  if (u < up) return sstep(0, 1, u / up);
  if (u < up + hold) return 1;
  if (u < up + hold + down) return 1 - sstep(0, 1, (u - up - hold) / down);
  return 0;
};
const kf = (vals, u) => {
  if (u <= 0) return vals[0];
  if (u >= 1) return vals[vals.length - 1];
  const s = u * (vals.length - 1), i = Math.floor(s), f = s - i;
  return mix(vals[i], vals[i + 1], f * f * (3 - 2 * f));
};
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(20261102);
const V3 = (x, y, z) => new THREE.Vector3(x, y, z);

// ---------- renderer, scene, camera
const renderer = new THREE.WebGLRenderer({ canvas, antialias: Q.aa, preserveDrawingBuffer: true });
renderer.setPixelRatio(Q.dpr);
renderer.setSize(W, H, false);
renderer.setClearColor(0x0b1120, 1);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.shadowMap.enabled = false;
const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x0b1120, 22, 42);
const camera = new THREE.PerspectiveCamera(30, W / H, 0.1, 100);
{
  const pm = new THREE.PMREMGenerator(renderer);
  const env = new THREE.Scene();
  env.background = new THREE.Color(0x141b2a);
  const panel = (w, h, c, p) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide }));
    m.position.copy(p); m.lookAt(0, 0, 0); env.add(m);
  };
  panel(7, 5, new THREE.Color(5, 4.7, 4.3), V3(-5, 6, 7));
  panel(4, 7, new THREE.Color(4, 1.7, 0.8), V3(7, 2, -5));
  panel(4, 7, new THREE.Color(0.9, 1.4, 3.2), V3(-7, 2, -5));
  panel(14, 14, new THREE.Color(0.22, 0.24, 0.3), V3(0, -9, 0));
  scene.environment = pm.fromScene(env, 0.03).texture;
  scene.environmentIntensity = 0.45;
}
const hemi = new THREE.HemisphereLight(0xc4d2ff, 0x221b2c, 0.7); scene.add(hemi);
const key = new THREE.DirectionalLight(0xffe9d2, 2.3); key.position.set(-3, 6, 9); key.target.position.set(0, 0.5, 1); scene.add(key, key.target);
const rimO = new THREE.DirectionalLight(0xff7a3a, 2.8); rimO.position.set(6, 3, -4); scene.add(rimO);
const rimB = new THREE.DirectionalLight(0x6f9cff, 2.2); rimB.position.set(-6, 3, -4); scene.add(rimB);
const glow = new THREE.PointLight(0x8fbfff, 9, 9, 1.5); glow.position.set(-1.3, 0.3, 2.6); scene.add(glow);

// ---------- procedural textures
function canvasTex(w, h, draw, ru = 1, rv = 1) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(ru, rv); t.anisotropy = 4;
  return t;
}
const ribs = (n) => canvasTex(512, 8, (g, w, h) => {
  for (let i = 0; i < 16; i++) {
    const x0 = i * w / 16, gr = g.createLinearGradient(x0, 0, x0 + w / 16, 0);
    gr.addColorStop(0, '#202020'); gr.addColorStop(0.5, '#ffffff'); gr.addColorStop(1, '#202020');
    g.fillStyle = gr; g.fillRect(x0, 0, w / 16 + 1, h);
  }
}, n / 16, 1);
const hairTex = canvasTex(1024, 512, (g, w, h) => {
  g.fillStyle = '#808080'; g.fillRect(0, 0, w, h); g.lineCap = 'round';
  for (let i = 0; i < 11000; i++) {
    const x = rnd() * w, y = rnd() * h, L = 5 + rnd() * 12, a = Math.PI / 2 + (rnd() - 0.5) * 0.8, v = Math.floor(30 + rnd() * 200);
    g.strokeStyle = `rgba(${v},${v},${v},0.75)`; g.lineWidth = 0.8 + rnd() * 1.6;
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * L, y + Math.sin(a) * L); g.stroke();
  }
});
const noiseTex = (n, rep, lo = 60, hi = 200) => canvasTex(n, n, (g, w, h) => {
  const im = g.createImageData(w, h);
  for (let i = 0; i < w * h; i++) { const v = lo + rnd() * (hi - lo); im.data[i * 4] = im.data[i * 4 + 1] = im.data[i * 4 + 2] = v; im.data[i * 4 + 3] = 255; }
  g.putImageData(im, 0, 0);
}, rep, rep);
const curlTex = canvasTex(256, 256, (g, w, h) => {
  g.fillStyle = '#808080'; g.fillRect(0, 0, w, h);
  for (let i = 0; i < 900; i++) {
    const x = rnd() * w, y = rnd() * h, r = 3 + rnd() * 6, v = Math.floor(40 + rnd() * 190);
    g.strokeStyle = `rgba(${v},${v},${v},0.8)`; g.lineWidth = 1.2;
    g.beginPath(); g.arc(x, y, r, rnd() * 6, rnd() * 6 + 3.5); g.stroke();
  }
});

// ---------- materials
const std = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.6, metalness: 0, ...o });
const M = {
  skin: std(0xD49A72, { roughness: 0.55 }),
  lid: std(0xCF9269, { roughness: 0.55, side: THREE.DoubleSide }),
  nose: std(0xC98762, { roughness: 0.5 }),
  lip: std(0xA2614A, { roughness: 0.45 }),
  beard: std(0x2A1B14, { roughness: 0.93, bumpMap: hairTex, bumpScale: 2.2, vertexColors: true, alphaTest: 0.5 }),
  hair: std(0x24170F, { roughness: 0.92, bumpMap: curlTex, bumpScale: 1.5 }),
  brow: std(0x24170F, { roughness: 0.9 }),
  lash: std(0x1A110C, { roughness: 0.8 }),
  eye: new THREE.MeshStandardMaterial({ color: 0xF7F3EC, roughness: 0.18 }),
  iris: new THREE.MeshStandardMaterial({ color: 0x5A3520, roughness: 0.3 }),
  pupil: new THREE.MeshStandardMaterial({ color: 0x0B0806, roughness: 0.2 }),
  glint: new THREE.MeshBasicMaterial({ color: 0xffffff }),
  mouthIn: std(0x3A1016, { roughness: 0.75 }),
  teeth: std(0xF8F4EC, { roughness: 0.3 }),
  tongue: std(0xC9585F, { roughness: 0.5 }),
  blush: new THREE.MeshStandardMaterial({ color: 0xE8737A, roughness: 0.7, transparent: true, opacity: 0, depthWrite: false }),
  beanie: new THREE.MeshStandardMaterial({ color: 0xEEE8DC, roughness: 0.93, bumpMap: ribs(34), bumpScale: 3.5 }),
  cuff: new THREE.MeshStandardMaterial({ color: 0xE9E2D4, roughness: 0.93, bumpMap: ribs(48), bumpScale: 4 }),
  pom: new THREE.MeshStandardMaterial({ color: 0xFF5A1F, roughness: 1, bumpMap: noiseTex(128, 3, 0, 255), bumpScale: 6 }),
  orange: std(0xFF5A1F, { roughness: 0.45 }),
  orangeSoft: std(0xFF8A5B, { roughness: 0.5 }),
  hoodie: new THREE.MeshStandardMaterial({ color: 0x34466A, roughness: 0.88, bumpMap: noiseTex(256, 7, 90, 170), bumpScale: 0.8 }),
  hoodieDark: new THREE.MeshStandardMaterial({ color: 0x253250, roughness: 0.9 }),
  rib: new THREE.MeshStandardMaterial({ color: 0x253250, roughness: 0.9, bumpMap: ribs(40), bumpScale: 2.5 }),
  string: std(0xEFE9DD, { roughness: 0.7 }),
  aglet: std(0xC9C0AE, { roughness: 0.35, metalness: 0.3 }),
  band: std(0x1E2638, { roughness: 0.4 }),
  cushion: std(0x232B3D, { roughness: 0.7 }),
  gold: std(0xE9B44C, { roughness: 0.25, metalness: 0.85 }),
};
const mesh = (geo, mat, cast = true, recv = true) => { const m = new THREE.Mesh(geo, mat); m.castShadow = cast; m.receiveShadow = recv; return m; };

// ---------- the character
const rig = new THREE.Group(); scene.add(rig);
const HS = V3(0.92, 1.0, 0.9);              // head ellipsoid radii
const headPivot = new THREE.Group(); headPivot.position.set(0, 0.55, 0); rig.add(headPivot);
const head = new THREE.Group(); head.position.set(0, 0.95, 0); headPivot.add(head);

// a point on the head surface: azimuth a (0 = front, + = screen right), elevation e, pushed out by off
const taper = (y) => 1 - 0.15 * sstep(0.15, -0.95, y);          // narrower towards the jaw
function headAt(x, y, z, off = 0) {
  const k = taper(y), rx = HS.x * k, rz = HS.z * k;
  const p = V3(x * rx, y * HS.y, z * rz);
  const n = V3(p.x / (rx * rx), p.y / (HS.y * HS.y), p.z / (rz * rz)).normalize();
  return { p: p.clone().addScaledVector(n, off), n };
}
function surf(a, e, off = 0) { return headAt(Math.sin(a) * Math.cos(e), Math.sin(e), Math.cos(a) * Math.cos(e), off); }

// skull
{
  const g = new THREE.SphereGeometry(1, 56, 40), ps = g.attributes.position;
  for (let i = 0; i < ps.count; i++) { const q = headAt(ps.getX(i), ps.getY(i), ps.getZ(i)).p; ps.setXYZ(i, q.x, q.y, q.z); }
  g.computeVertexNormals();
  head.add(mesh(g, M.skin));
}

// beard: an offset shell of the head with a smooth mask (alpha test gives a clean edge), thicker at the chin
{
  const g = new THREE.SphereGeometry(1, 128, 88);
  const pos = g.attributes.position, col = new Float32Array(pos.count * 4);
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const a = Math.atan2(x, z), e = Math.asin(clamp(y, -1, 1)), A = Math.abs(a);
    const eTop = -0.15 + 0.57 * Math.pow(sstep(0.5, 1.42, A), 1.25);         // cheek line, up to the sideburns
    const aMax = mix(1.40, 1.86, sstep(-0.10, -0.42, e));                          // in front of the ears, round the jaw lower down
    const d = Math.min(eTop - e, aMax - A);
    const alpha = clamp(0.5 + d * 24);
    const chin = Math.exp(-((a / 0.5) ** 2 + ((e + 0.86) / 0.32) ** 2));
    const side = sstep(0.7, 1.5, A) * sstep(-0.2, -0.9, e);
    const lipDip = Math.exp(-((a / 0.32) ** 2 + ((e + 0.36) / 0.12) ** 2));
    const th = Math.max(0.02, 0.022 + 0.07 * sstep(0, 0.16, d) + 0.24 * chin - 0.03 * side - 0.06 * lipDip);
    const { p: P0, n } = headAt(x, y, z);
    P0.addScaledVector(n, th);
    pos.setXYZ(i, P0.x, P0.y, P0.z);
    const v = 0.9 + 0.2 * rnd();
    col[i * 4] = v; col[i * 4 + 1] = v; col[i * 4 + 2] = v; col[i * 4 + 3] = alpha;
  }
  g.setAttribute('color', new THREE.BufferAttribute(col, 4));
  g.computeVertexNormals();
  head.add(mesh(g, M.beard));
}

// ears and earring
for (const s of [-1, 1]) {
  const { p } = surf(1.57 * s, 0.06, -0.02);
  const ear = mesh(new THREE.SphereGeometry(1, 24, 16), M.skin);
  ear.scale.set(0.075, 0.19, 0.13); ear.position.copy(p).add(V3(0.04 * s, 0, -0.02)); ear.rotation.y = 0.25 * s;
  head.add(ear);
  const inner = mesh(new THREE.SphereGeometry(1, 16, 12), M.nose);
  inner.scale.set(0.03, 0.12, 0.075); inner.position.copy(ear.position).add(V3(0.05 * s, 0, 0.01)); inner.rotation.y = 0.25 * s;
  head.add(inner);
  if (s < 0) {
    const ring = mesh(new THREE.TorusGeometry(0.045, 0.012, 8, 24), M.gold);
    ring.position.copy(ear.position).add(V3(-0.05, -0.17, 0.03)); ring.rotation.y = Math.PI / 2 - 0.3;
    head.add(ring);
  }
}

// nose
{
  const { p } = surf(0, -0.02, 0.06);
  const n = mesh(new THREE.SphereGeometry(0.125, 24, 16), M.nose, false); n.scale.set(0.9, 1.12, 1.05); n.position.copy(p).add(V3(0, 0.01, -0.01)); head.add(n);
  for (const s of [-1, 1]) {
    const w = mesh(new THREE.SphereGeometry(0.062, 14, 10), M.nose, false); w.position.copy(p).add(V3(0.085 * s, -0.055, -0.045)); head.add(w);
  }
}

// eyes: ball (white, iris, pupil, glint) that can look around, plus upper and lower lids that close over it
const eyes = [];
for (const s of [-1, 1]) {
  const { p } = surf(0.36 * s, 0.17, -0.07);
  const g = new THREE.Group(); g.position.copy(p); head.add(g);
  const ball = new THREE.Group(); g.add(ball);
  ball.add(mesh(new THREE.SphereGeometry(0.15, 28, 20), M.eye, false));
  const iris = mesh(new THREE.SphereGeometry(0.1508, 40, 12, 0, Math.PI * 2, 0, 0.6), M.iris, false); iris.rotation.x = Math.PI / 2; ball.add(iris);
  const pupil = mesh(new THREE.SphereGeometry(0.1516, 32, 8, 0, Math.PI * 2, 0, 0.29), M.pupil, false); pupil.rotation.x = Math.PI / 2; ball.add(pupil);
  const gl = mesh(new THREE.SphereGeometry(0.021, 12, 8), M.glint, false, false); gl.position.set(-0.05, 0.055, 0.14); ball.add(gl);
  const up = mesh(new THREE.SphereGeometry(0.163, 28, 12, 0, Math.PI * 2, 0, Math.PI / 2), M.lid, false); g.add(up);
  const lash = mesh(new THREE.TorusGeometry(0.163, 0.013, 8, 48), M.lash, false); lash.rotation.x = Math.PI / 2; up.add(lash);
  const lo = mesh(new THREE.SphereGeometry(0.16, 28, 12, 0, Math.PI * 2, Math.PI / 2, Math.PI / 2), M.lid, false); g.add(lo);
  eyes.push({ g, ball, up, lo, s });
}

// brows
const brows = [];
for (const s of [-1, 1]) {
  const { p } = surf(0.37 * s, 0.42, 0.035);
  const b = mesh(new THREE.CapsuleGeometry(0.056, 0.24, 6, 14), M.brow, false);
  const holder = new THREE.Group(); holder.position.copy(p); holder.rotation.y = 0.37 * s; head.add(holder);
  b.rotation.z = Math.PI / 2 - 0.12 * s; holder.add(b);
  brows.push({ holder, b, s, y0: p.y });
}

// cheeks (blush shows at the happy moments)
const blush = [];
for (const s of [-1, 1]) {
  const { p, n } = surf(0.56 * s, 0.02, 0.012);
  const b = new THREE.Mesh(new THREE.SphereGeometry(1, 20, 12), M.blush);
  b.scale.set(0.13, 0.075, 0.02); b.position.copy(p); b.lookAt(p.clone().add(n)); head.add(b); blush.push(b);
}

// moustache
for (const s of [-1, 1]) {
  const { p } = surf(0.18 * s, -0.19, 0.1);
  const m = mesh(new THREE.SphereGeometry(1, 28, 18), M.beard.clone());
  m.material.vertexColors = false; m.material.alphaTest = 0;
  m.scale.set(0.25, 0.095, 0.12); m.position.copy(p); m.rotation.set(0.15, 0.5 * s, -0.36 * s);
  head.add(m);
}

// mouth: lip ring, dark inside, teeth and tongue, all reshaped every frame from the visemes
const mouth = new THREE.Group();
{
  const { p, n } = surf(0, -0.37, 0.04);
  mouth.position.copy(p); mouth.lookAt(p.clone().add(n)); head.add(mouth);
}
const lipM = mesh(new THREE.SphereGeometry(1, 28, 14), M.lip, false); mouth.add(lipM);
const cav = mesh(new THREE.SphereGeometry(1, 28, 14), M.mouthIn, false); mouth.add(cav);
const teeth = mesh(new THREE.CapsuleGeometry(0.5, 1, 4, 12), M.teeth, false); teeth.rotation.z = Math.PI / 2; mouth.add(teeth);
const tongue = mesh(new THREE.SphereGeometry(1, 24, 12), M.tongue, false); mouth.add(tongue);

// curly hair under the beanie
{
  const add = (a, e, r) => { const { p } = surf(a, e, -0.02); const c = mesh(new THREE.SphereGeometry(r, 12, 10), M.hair, false); c.position.copy(p); head.add(c); };
  for (let k = 0; k < 2; k++) for (const s of [-1, 1]) {
    for (let a = 0.86; a <= Math.PI + 0.01; a += 0.27) add(s * a + (rnd() - 0.5) * 0.08, 0.42 - k * 0.2 - (a < 1.3 ? 0 : 0.03), 0.12 + rnd() * 0.04 - k * 0.01);
  }
  for (const s of [-1, 1]) add(0.74 * s, 0.5, 0.1);
}

// beanie: crown, rolled cuff, pom-pom and a small tag
{
  const crown = mesh(new THREE.SphereGeometry(1, 56, 30, 0, Math.PI * 2, 0, 0.98), M.beanie);
  crown.scale.set(1.0, 1.17, 0.98); crown.position.set(0, 0.0, -0.01); head.add(crown);
  const cuff = mesh(new THREE.TorusGeometry(0.885, 0.16, 18, 72), M.cuff);
  cuff.rotation.x = Math.PI / 2; cuff.scale.set(1.0, 0.985, 1.2); cuff.position.set(0, 0.5, -0.01); head.add(cuff);
  const pom = mesh(new THREE.SphereGeometry(0.25, 28, 20), M.pom); pom.position.set(0, 1.33, -0.02); head.add(pom);
  const tag = mesh(new THREE.BoxGeometry(0.2, 0.085, 0.05), M.orange);
  const ta = 0.55; tag.position.set(Math.sin(ta) * 1.04, 0.5, Math.cos(ta) * 1.02); tag.rotation.y = ta; head.add(tag);
}

// neck, hoodie, collar, drawstrings, headphones
const torso = new THREE.Group(); rig.add(torso);
{
  const neck = mesh(new THREE.CylinderGeometry(0.31, 0.35, 0.8, 28), M.skin); neck.position.set(0, 0.45, -0.03); rig.add(neck);
  const prof = new THREE.CatmullRomCurve3([V3(0.001, 0.2, 0), V3(0.45, 0.2, 0), V3(0.74, 0.12, 0), V3(1.08, -0.02, 0), V3(1.33, -0.22, 0),
    V3(1.46, -0.52, 0), V3(1.52, -0.98, 0), V3(1.56, -1.6, 0), V3(1.58, -2.7, 0)]).getPoints(48).map(v => new THREE.Vector2(v.x, v.y));
  const body = mesh(new THREE.LatheGeometry(prof, 64), M.hoodie); body.scale.z = 0.7; torso.add(body);
  const collar = mesh(new THREE.TorusGeometry(0.57, 0.17, 16, 56), M.hoodieDark); collar.rotation.x = Math.PI / 2; collar.scale.set(1, 0.84, 1); collar.position.y = 0.2; torso.add(collar);
  const hood = mesh(new THREE.SphereGeometry(1, 40, 24), M.hoodieDark); hood.scale.set(0.88, 0.42, 0.42); hood.position.set(0, 0.3, -0.5); torso.add(hood);
  const trim = mesh(new THREE.TorusGeometry(0.44, 0.045, 12, 64), M.orange); trim.rotation.x = Math.PI / 2; trim.scale.set(1, 0.84, 1); trim.position.y = 0.32; torso.add(trim);
  const rad = (y) => { let best = prof[0]; for (const q of prof) if (Math.abs(q.y - y) < Math.abs(best.y - y)) best = q; return best.x; };
  for (const s of [-1, 1]) {
    const pts = [];
    for (let k = 0; k <= 8; k++) { const y = 0.12 - k * 0.1, x = s * (0.17 + k * 0.006); const r = rad(y); const z = Math.sqrt(Math.max(0, r * r - x * x)) * 0.7 + 0.035; pts.push(V3(x, y, Math.max(z, 0.62))); }
    const str = mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.024, 8), M.string, false); torso.add(str);
    const end = pts[pts.length - 1];
    const ag = mesh(new THREE.CylinderGeometry(0.034, 0.03, 0.12, 12), M.aglet); ag.position.copy(end).add(V3(0, -0.05, 0.005)); torso.add(ag);
  }
  const band = mesh(new THREE.TorusGeometry(0.66, 0.055, 12, 60, Math.PI * 1.25), M.band);
  band.rotation.set(Math.PI / 2, 0, Math.PI * 0.875); band.position.set(0, 0.36, -0.04); torso.add(band);
  for (const s of [-1, 1]) {
    const cup = new THREE.Group(); cup.position.set(0.64 * s, 0.3, 0.3); cup.rotation.set(-0.25, 0.55 * s, 0); torso.add(cup);
    const shell = mesh(new THREE.CylinderGeometry(0.21, 0.21, 0.13, 36), M.orange); shell.rotation.x = Math.PI / 2; cup.add(shell);
    const disc = mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.135, 32), M.orangeSoft); disc.rotation.x = Math.PI / 2; cup.add(disc);
    const cush = mesh(new THREE.TorusGeometry(0.17, 0.06, 12, 36), M.cushion); cush.position.z = -0.08; cup.add(cush);
  }
}

// arms: aimed by direction vectors (shoulder to elbow, elbow to wrist) so poses are easy to author.
// The left arm is the right arm mirrored, so every pose is written for the screen-right arm.
function makeHand() {
  const g = new THREE.Group();
  const palm = mesh(new THREE.SphereGeometry(0.15, 28, 20), M.skin); palm.scale.set(0.66, 1.05, 1.0); palm.position.y = -0.12; g.add(palm);
  const fingers = [];
  for (const [z, L] of [[0.095, 0.15], [0.033, 0.17], [-0.031, 0.16], [-0.09, 0.13]]) {
    const root = new THREE.Group(); root.position.set(0.0, -0.235, z); g.add(root);
    const a = mesh(new THREE.CapsuleGeometry(0.042, L * 0.5, 3, 8), M.skin, false); a.position.y = -(L * 0.25 + 0.03); root.add(a);
    const mid = new THREE.Group(); mid.position.y = -(L * 0.5 + 0.03); root.add(mid);
    const b = mesh(new THREE.CapsuleGeometry(0.04, L * 0.42, 3, 8), M.skin, false); b.position.y = -(L * 0.21 + 0.03); mid.add(b);
    fingers.push({ root, mid });
  }
  const th = new THREE.Group(); th.position.set(-0.025, -0.12, 0.115); g.add(th);
  const t1 = mesh(new THREE.CapsuleGeometry(0.048, 0.08, 3, 8), M.skin, false); t1.position.y = -0.07; th.add(t1);
  const t2 = mesh(new THREE.CapsuleGeometry(0.044, 0.06, 3, 8), M.skin, false); t2.position.y = -0.16; th.add(t2);
  return { g, fingers, th };
}
function makeArm(side) {
  const root = new THREE.Group(); root.position.set(1.08 * side, -0.36, 0.0); root.scale.x = side; rig.add(root);
  const sh = new THREE.Group(); root.add(sh);
  sh.add(mesh(new THREE.SphereGeometry(0.22, 24, 18), M.hoodie));
  const up = mesh(new THREE.CapsuleGeometry(0.215, 0.6, 6, 18), M.hoodie); up.position.y = -0.38; sh.add(up);
  const el = new THREE.Group(); el.position.y = -0.8; sh.add(el);
  const fo = mesh(new THREE.CapsuleGeometry(0.19, 0.5, 6, 18), M.hoodie); fo.position.y = -0.3; el.add(fo);
  const cuffM = mesh(new THREE.CylinderGeometry(0.205, 0.2, 0.15, 28), M.rib); cuffM.position.y = -0.64; el.add(cuffM);
  const wr = new THREE.Group(); wr.position.y = -0.72; el.add(wr);
  const hand = makeHand(); hand.g.scale.setScalar(1.35); wr.add(hand.g);
  return { root, sh, el, wr, hand, side };
}
const arms = { r: makeArm(1), l: makeArm(-1) };

// poses for the screen-right arm, in rig space (+x out to the side, +y up, +z towards the camera).
// up: shoulder to elbow, fo: elbow to wrist, palm: which way the palm faces, c: finger curls, th: thumb direction (hand space)
const POSES = {
  down:  { up: [0.3, -1, 0.14], fo: [0.18, -1, 0.36], palm: [-1, 0, 0.25], c: [0.45, 0.5, 0.55, 0.6], th: [0.25, -0.7, 0.65], sp: 0.05 },
  point: { up: [0.5, -0.2, 0.8], fo: [-0.15, 0.93, 0.33], palm: [-0.85, 0, 0.5], c: [0.0, 1.55, 1.6, 1.6], th: [-0.6, -0.6, 0.5], sp: 0 },
  thumb: { up: [0.5, -0.4, 0.62], fo: [0.0, 0.97, 0.25], palm: [-0.8, 0, -0.6], c: [1.6, 1.65, 1.65, 1.6], th: [0.1, -1, 0.05], sp: 0, ts: 1.35 },
  open:  { up: [0.55, -0.25, 0.6], fo: [0.05, 0.98, 0.15], palm: [0, 0, 1], c: [0.05, 0.03, 0.05, 0.1], th: [-0.35, -0.45, 0.82], sp: 0.16 },
  shrug: { up: [0.28, -0.95, 0.25], fo: [0.35, 0.32, 0.88], palm: [0.1, 1, 0.1], c: [0.25, 0.25, 0.3, 0.35], th: [0.0, -0.5, 0.9], sp: 0.12 },
  raise: { up: [0.36, 0.9, 0.22], fo: [0.12, 0.98, 0.12], palm: [0, 0, 1], c: [0.05, 0.03, 0.05, 0.1], th: [-0.35, -0.45, 0.82], sp: 0.16 },
};
const lerpArr = (a, b, t) => a.map((v, i) => mix(v, b[i], t));
for (const k of Object.keys(POSES)) if (POSES[k].ts == null) POSES[k].ts = 1;
function lerpPose(a, b, t) {
  const o = {};
  for (const k of Object.keys(a)) o[k] = Array.isArray(a[k]) ? lerpArr(a[k], b[k], t) : mix(a[k], b[k], t);
  return o;
}
const DOWN = V3(0, -1, 0), qTmp = new THREE.Quaternion(), vTmp = V3(0, 0, 0);
function applyPose(arm, p, extra) {
  const up = V3(...p.up).normalize();
  arm.sh.quaternion.setFromUnitVectors(DOWN, up);
  if (extra && extra.sh) arm.sh.quaternion.premultiply(new THREE.Quaternion().setFromAxisAngle(V3(1, 0, 0), extra.sh));
  const inv = arm.sh.quaternion.clone().invert();
  const fo = V3(...p.fo).normalize().applyQuaternion(inv);
  arm.el.quaternion.setFromUnitVectors(DOWN, fo);
  // wrist roll so the palm faces where the pose says
  const elWorldQ = arm.sh.quaternion.clone().multiply(arm.el.quaternion);
  const palm = V3(...p.palm).normalize().applyQuaternion(elWorldQ.clone().invert());
  const roll = Math.atan2(palm.z, -palm.x);
  arm.wr.rotation.set(extra && extra.wx || 0, roll, extra && extra.wz || 0);
  arm.hand.fingers.forEach((f, i) => {
    const c = p.c[i] + (extra && extra.curl || 0);
    f.root.rotation.set(0, 0, -c);
    f.root.rotation.x = (i - 1.5) * -p.sp;
    f.mid.rotation.set(0, 0, -c * 1.15);
  });
  arm.hand.th.quaternion.setFromUnitVectors(DOWN, V3(...p.th).normalize());
  arm.hand.th.scale.setScalar(p.ts || 1);
}



// ---------- extra poses for a desk
Object.assign(POSES, {
  type:  { up: [0.22, -0.88, 0.42], fo: [-0.2, -0.06, 0.98], palm: [0, -1, 0.1], c: [0.3, 0.32, 0.35, 0.4], th: [-0.3, -0.6, 0.7], sp: 0.04, ts: 1 },
  cheer: { up: [0.45, 0.85, 0.15], fo: [0.15, 0.98, 0.05], palm: [0, 0, 1], c: [0.05, 0.03, 0.05, 0.1], th: [-0.35, -0.45, 0.82], sp: 0.18, ts: 1 },
  screen: { up: [0.35, -0.55, 0.75], fo: [-0.75, 0.25, 0.6], palm: [0, -0.3, 1], c: [0.0, 1.55, 1.6, 1.6], th: [-0.6, -0.6, 0.5], sp: 0, ts: 1 },
  pointdown: { up: [0.4, -0.55, 0.72], fo: [0.05, -0.55, 0.85], palm: [-0.9, 0, 0.3], c: [0.0, 1.55, 1.6, 1.6], th: [-0.6, -0.6, 0.5], sp: 0, ts: 1 },
});

// ---------- the room: desk, monitor, keyboard, mug, plant, back wall with a night window
const ROOM = {};
{
  const lam = (c, o = {}) => new THREE.MeshLambertMaterial({ color: c, ...o });
  const wood = lam(0x7A4B33), woodDark = lam(0x5B3624);
  const black = std(0x10141d, { roughness: 0.35 }), metal = std(0x9aa3b2, { roughness: 0.3, metalness: 0.6 });
  const desk = mesh(new THREE.BoxGeometry(7.2, 0.24, 2.5), wood); desk.position.set(0, -1.17, 2.4); scene.add(desk);
  const front = mesh(new THREE.BoxGeometry(7.0, 2.8, 0.12), woodDark); front.position.set(0, -2.65, 3.55); scene.add(front);
  // monitor on the left, turned towards the guy and the camera
  const mon = new THREE.Group(); mon.position.set(-1.85, -1.05, 2.2); mon.rotation.y = 0.6; scene.add(mon);
  const foot = mesh(new THREE.BoxGeometry(0.9, 0.06, 0.55), metal); foot.position.y = 0.03; mon.add(foot);
  const neckM = mesh(new THREE.BoxGeometry(0.14, 0.75, 0.1), metal); neckM.position.set(0, 0.42, -0.1); mon.add(neckM);
  const frame = mesh(new THREE.BoxGeometry(2.55, 1.62, 0.1), black); frame.position.set(0, 1.45, 0); mon.add(frame);
  const sc = document.createElement('canvas'); sc.width = 1024; sc.height = 640;
  const stex = new THREE.CanvasTexture(sc); stex.colorSpace = THREE.SRGBColorSpace; stex.anisotropy = 4;
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 1.5), new THREE.MeshBasicMaterial({ map: stex, toneMapped: false }));
  screen.position.set(0, 1.45, 0.052); mon.add(screen);
  ROOM.mon = mon; ROOM.screen = screen; ROOM.sc = sc; ROOM.stex = stex;
  // keyboard, mug, plant
  const kb = mesh(new THREE.BoxGeometry(2.0, 0.07, 0.62), lam(0x1b2232)); kb.position.set(0.05, -1.02, 1.62); scene.add(kb);
  const keys = new THREE.InstancedMesh(new THREE.BoxGeometry(0.12, 0.03, 0.11), new THREE.MeshLambertMaterial({ color: 0x2c3549 }), 52);
  { const m4 = new THREE.Matrix4(); let n = 0; for (let r = 0; r < 4; r++) for (let c = 0; c < 13; c++) { m4.makeTranslation(-0.85 + c * 0.142, -0.97, 1.4 + r * 0.14); keys.setMatrixAt(n++, m4); } }
  scene.add(keys);
  const mug = mesh(new THREE.CylinderGeometry(0.2, 0.18, 0.4, 24), std(0xFF5A1F, { roughness: 0.45 })); mug.position.set(1.55, -0.85, 2.5); scene.add(mug);
  const handle = mesh(new THREE.TorusGeometry(0.11, 0.035, 8, 16), mug.material); handle.position.set(1.77, -0.84, 2.5); handle.rotation.y = Math.PI / 2; scene.add(handle);
  const pot = mesh(new THREE.CylinderGeometry(0.28, 0.22, 0.45, 20), lam(0xE9E2D4)); pot.position.set(3.05, -0.83, 2.0); scene.add(pot);
  const leafM = lam(0x3f8f5a, { flatShading: true });
  for (let i = 0; i < 7; i++) {
    const lf = mesh(new THREE.ConeGeometry(0.16, 0.9, 5), leafM);
    const a = i / 7 * Math.PI * 2; lf.position.set(3.05 + Math.cos(a) * 0.1, -0.2, 2.0 + Math.sin(a) * 0.1);
    lf.rotation.set(Math.sin(a) * 0.5, 0, -Math.cos(a) * 0.5); scene.add(lf);
  }
  // back wall, neon strip and a window with city lights
  const wall = new THREE.Mesh(new THREE.PlaneGeometry(40, 24), lam(0x161f35)); wall.position.set(0, 2, -3.6); scene.add(wall);
  const neon = new THREE.Mesh(new THREE.BoxGeometry(9, 0.07, 0.05), new THREE.MeshBasicMaterial({ color: 0xff6a2a, toneMapped: false })); neon.position.set(0.5, 5.2, -3.5); scene.add(neon);
  const wc = document.createElement('canvas'); wc.width = 1024; wc.height = 576;
  {
    const g = wc.getContext('2d');
    const gr = g.createLinearGradient(0, 0, 0, 576); gr.addColorStop(0, '#0b1430'); gr.addColorStop(1, '#2a2350'); g.fillStyle = gr; g.fillRect(0, 0, 1024, 576);
    for (let i = 0; i < 26; i++) { const x = i * 40 + rnd() * 20, h = 120 + rnd() * 300; g.fillStyle = `rgba(10,14,32,${0.85 + rnd() * 0.15})`; g.fillRect(x, 576 - h, 34 + rnd() * 20, h); }
    for (let i = 0; i < 160; i++) {
      const x = rnd() * 1024, y = 200 + rnd() * 376, r = 3 + rnd() * 14, hue = rnd() < 0.6 ? '255,190,120' : '140,180,255';
      const rg = g.createRadialGradient(x, y, 0, x, y, r); rg.addColorStop(0, `rgba(${hue},${0.5 + rnd() * 0.4})`); rg.addColorStop(1, `rgba(${hue},0)`);
      g.fillStyle = rg; g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
    }
  }
  const wtex = new THREE.CanvasTexture(wc); wtex.colorSpace = THREE.SRGBColorSpace;
  const win = new THREE.Mesh(new THREE.PlaneGeometry(8, 4.5), new THREE.MeshBasicMaterial({ map: wtex, toneMapped: false })); win.position.set(-0.4, 2.6, -3.55); scene.add(win);
  const sill = mesh(new THREE.BoxGeometry(8.4, 0.12, 0.3), lam(0x232c45)); sill.position.set(-0.4, 0.3, -3.45); scene.add(sill);
  for (const x of [-4.4, 3.6]) { const p = mesh(new THREE.BoxGeometry(0.12, 4.7, 0.2), lam(0x232c45)); p.position.set(x, 2.6, -3.45); scene.add(p); }
}

// ---------- the robot sidekick
const BOT = {};
{
  const white = std(0xEEECE7, { roughness: 0.32 }), dark = std(0x0e1424, { roughness: 0.25 });
  const cyan = new THREE.MeshBasicMaterial({ color: 0x7df9ff, toneMapped: false });
  const orange = new THREE.MeshBasicMaterial({ color: 0xff7a1a, toneMapped: false });
  const root = new THREE.Group(); root.position.set(2.0, 0.95, 1.7); scene.add(root);
  const body = new THREE.Group(); root.add(body);
  const torso = mesh(new THREE.SphereGeometry(0.4, 28, 20), white); torso.scale.set(1, 1.08, 0.95); body.add(torso);
  const belly = mesh(new THREE.CircleGeometry(0.12, 20), orange); belly.position.set(0, 0.02, 0.385); body.add(belly);
  const headG = new THREE.Group(); headG.position.y = 0.7; body.add(headG);
  const headM = mesh(new THREE.SphereGeometry(1, 32, 22), white); headM.scale.set(0.6, 0.48, 0.5); headG.add(headM);
  const visor = mesh(new THREE.SphereGeometry(1, 32, 16), dark); visor.scale.set(0.47, 0.32, 0.2); visor.position.z = 0.36; headG.add(visor);
  const eyeL = new THREE.Mesh(new THREE.CapsuleGeometry(0.05, 0.07, 4, 10), cyan); eyeL.position.set(-0.15, 0.0, 0.55); headG.add(eyeL);
  const eyeR = eyeL.clone(); eyeR.position.x = 0.15; headG.add(eyeR);
  const happyL = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.022, 6, 16, Math.PI), cyan); happyL.position.set(-0.15, -0.02, 0.555); headG.add(happyL);
  const happyR = happyL.clone(); happyR.position.x = 0.15; headG.add(happyR);
  const stalk = mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.28, 8), white); stalk.position.y = 0.6; headG.add(stalk);
  const ball = new THREE.Mesh(new THREE.SphereGeometry(0.075, 16, 12), orange); ball.position.y = 0.76; headG.add(ball);
  const arm = (s) => {
    const piv = new THREE.Group(); piv.position.set(0.42 * s, 0.18, 0); body.add(piv);
    const a = mesh(new THREE.CapsuleGeometry(0.075, 0.26, 4, 10), white); a.position.y = -0.2; piv.add(a);
    const h = mesh(new THREE.SphereGeometry(0.09, 14, 10), white); h.position.y = -0.4; piv.add(h);
    return piv;
  };
  const armL = arm(-1), armR = arm(1);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(0.26, 0.03, 8, 32), cyan); ring.rotation.x = Math.PI / 2; ring.position.y = -0.55; root.add(ring);
  Object.assign(BOT, { root, body, headG, eyeL, eyeR, happyL, happyR, ball, armL, armR, ring });
}

// ---------- monitor screen content (2D canvas redrawn only when its state changes)
const SC = ROOM.sc.getContext('2d');
function rr(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }
const MONO = '"JetBrains Mono", monospace', SANS = '"Archivo", sans-serif';
let lastKey = '';
function drawScreen(sc, u, idx = 0) {
  const type = sc ? sc.type : 'blank';
  const step = Math.floor(u * 15);
  const keyS = idx + ':' + type + ':' + (['chat', 'code', 'reels', 'cost', 'checkout', 'doc'].includes(type) ? Math.min(step, 90) : 0) + ':' + (sc && (sc.text || sc.title) || '');
  if (keyS === lastKey) return;
  lastKey = keyS;
  const g = SC, w = 1024, h = 640;
  const bg = g.createLinearGradient(0, 0, 0, h); bg.addColorStop(0, '#111a2e'); bg.addColorStop(1, '#0a1020'); g.fillStyle = bg; g.fillRect(0, 0, w, h);
  g.fillStyle = '#1b2640'; g.fillRect(0, 0, w, 44);
  ['#ff5f57', '#febc2e', '#28c840'].forEach((c, i) => { g.fillStyle = c; g.beginPath(); g.arc(28 + i * 26, 22, 8, 0, 7); g.fill(); });
  g.font = `600 22px ${MONO}`; g.fillStyle = '#8aa0c8'; g.fillText(sc && sc.title || '', 120, 30);
  if (type === 'chat') {
    const q = sc.text || 'make me a 3D reel';
    const n = Math.min(q.length, Math.floor(u * 22));
    g.font = `700 40px ${SANS}`;
    const tw = Math.max(260, g.measureText(q).width + 60);
    g.fillStyle = '#FF6A2A'; rr(g, w - 60 - tw, 90, tw, 84, 26); g.fill();
    g.fillStyle = '#ffffff'; g.fillText(q.slice(0, n) + (n < q.length && step % 2 ? '|' : ''), w - 30 - tw, 146);
    if (u > q.length / 22 + 0.3) {
      const v = u - q.length / 22 - 0.3;
      g.fillStyle = '#26324f'; rr(g, 60, 220, 520, 84, 26); g.fill();
      if (v < 0.8) { for (let i = 0; i < 3; i++) { g.fillStyle = (step + i) % 3 ? '#6c7da3' : '#c9d6f2'; g.beginPath(); g.arc(110 + i * 34, 262, 10, 0, 7); g.fill(); } }
      else {
        g.fillStyle = '#e7eefc'; g.font = `700 38px ${SANS}`; g.fillText(sc.reply || 'Building it now', 92, 274);
        g.fillStyle = '#26324f'; rr(g, 60, 340, 900, 34, 17); g.fill();
        g.fillStyle = '#28c840'; rr(g, 60, 340, Math.max(34, 900 * clamp((v - 0.8) / 1.6)), 34, 17); g.fill();
        g.fillStyle = '#8aa0c8'; g.font = `600 26px ${MONO}`; g.fillText(`${Math.round(100 * clamp((v - 0.8) / 1.6))}%  head  beard  beanie  hoodie  lights`, 60, 420);
      }
    }
  } else if (type === 'code') {
    const lines = ['const guy = new Character()', 'guy.add(beard, beanie, hoodie)', 'guy.eyes.lookAt(camera)', 'scene.add(desk, monitor, bot)', 'bot.wave()', 'for (const f of frames) render(f)', '// 0 tokens per new reel'];
    g.font = `600 34px ${MONO}`;
    const shown = Math.min(lines.length, Math.floor(u * 3.2) + 1);
    for (let i = 0; i < shown; i++) {
      const L = lines[i]; g.fillStyle = '#4b5b80'; g.fillText(String(i + 1).padStart(2, ' '), 40, 110 + i * 66);
      g.fillStyle = L.startsWith('//') ? '#28c840' : (i % 2 ? '#7df9ff' : '#ffd27a'); g.fillText(L, 110, 110 + i * 66);
    }
  } else if (type === 'reels') {
    for (let i = 0; i < 3; i++) {
      const x = 70 + i * 312, y = 80 + (i % 2) * 18;
      g.fillStyle = '#1e2a46'; rr(g, x, y, 260, 520, 30); g.fill();
      const gr = g.createLinearGradient(x, y, x, y + 520); gr.addColorStop(0, ['#3b2a72', '#173d5c', '#5a2a3a'][i]); gr.addColorStop(1, ['#ff7a3a', '#2ac7c7', '#ffb347'][i]);
      g.fillStyle = gr; rr(g, x + 12, y + 12, 236, 496, 22); g.fill();
      g.fillStyle = 'rgba(255,255,255,0.85)';
      g.beginPath(); g.arc(x + 130, y + 210 + Math.sin(u * 3 + i) * 10, 46, 0, 7); g.fill();
      g.fillStyle = 'rgba(10,14,30,0.55)'; rr(g, x + 70, y + 270, 120, 150, 24); g.fill();
      g.fillStyle = '#ffffff'; g.beginPath(); g.moveTo(x + 112, y + 440); g.lineTo(x + 112, y + 488); g.lineTo(x + 150, y + 464); g.closePath(); g.fill();
    }
  } else if (type === 'checkout') {
    g.fillStyle = '#f4f1ea'; rr(g, 212, 90, 600, 470, 28); g.fill();
    g.fillStyle = '#111827'; g.font = `900 46px ${SANS}`; g.fillText('3D REEL GUIDE', 262, 170);
    g.fillStyle = '#6b7280'; g.font = `600 28px ${SANS}`; g.fillText('PDF + prompts', 262, 214);
    g.fillStyle = '#111827'; g.font = `900 110px ${SANS}`; g.fillText(sc.price || '£39', 262, 350);
    g.fillStyle = '#16a34a'; rr(g, 262, 400, 500, 100, 22); g.fill();
    g.fillStyle = '#ffffff'; g.font = `900 44px ${SANS}`; g.fillText('BUY NOW', 412, 466);
    const cx = 560 + Math.cos(u * 2) * 40, cy = 470 + Math.sin(u * 2.4) * 18;
    g.fillStyle = '#111'; g.beginPath(); g.moveTo(cx, cy); g.lineTo(cx, cy + 46); g.lineTo(cx + 13, cy + 34); g.lineTo(cx + 30, cy + 40); g.closePath(); g.fill();
  } else if (type === 'cost') {
    g.fillStyle = '#f4f1ea'; rr(g, 252, 70, 520, 510, 24); g.fill();
    g.fillStyle = '#111827'; g.font = `900 40px ${SANS}`; g.fillText('RECEIPT', 412, 140);
    const rows = [['Three.js', '£0.00'], ['Render', '£0.00'], ['Character', '£0.00']];
    g.font = `600 34px ${MONO}`;
    rows.forEach(([a, b], i) => { if (u > 0.25 * i) { g.fillStyle = '#374151'; g.fillText(a, 300, 230 + i * 70); g.fillText(b, 590, 230 + i * 70); } });
    g.strokeStyle = '#9ca3af'; g.setLineDash([10, 10]); g.beginPath(); g.moveTo(300, 430); g.lineTo(724, 430); g.stroke(); g.setLineDash([]);
    if (u > 0.9) { g.fillStyle = '#16a34a'; g.font = `900 70px ${SANS}`; g.fillText('TOTAL £0', 330, 520); }
  } else if (type === 'doc') {
    const L = sc.lines || [];
    let y = 100;
    L.forEach((ln, i) => {
      const o = typeof ln === 'string' ? { t: ln } : ln;
      if (u < (o.at != null ? o.at : i * 0.25)) return;
      const big = o.s === 'big';
      g.font = big ? `900 92px ${SANS}` : (o.mono ? `600 32px ${MONO}` : `700 38px ${SANS}`);
      const tw = g.measureText(o.t).width;
      if (o.s === 'bad') { g.fillStyle = 'rgba(229,72,77,0.28)'; g.fillRect(52, y - 40, tw + 24, 54); }
      if (o.s === 'good') { g.fillStyle = 'rgba(40,200,64,0.22)'; g.fillRect(52, y - 40, tw + 24, 54); }
      g.fillStyle = o.s === 'dim' ? '#5d6f96' : o.s === 'bad' ? '#ff9a9e' : o.s === 'good' ? '#8af0a0' : big ? (o.c || '#ffffff') : '#e7eefc';
      g.fillText(o.t, 64, y);
      if (o.s === 'strike') { g.strokeStyle = '#e5484d'; g.lineWidth = 6; g.beginPath(); g.moveTo(58, y - 13); g.lineTo(70 + tw, y - 13); g.stroke(); }
      y += big ? 112 : 64;
    });
    if (sc.stamp && u > (sc.stampAt || 1.2)) {
      const k = clamp((u - (sc.stampAt || 1.2)) / 0.18);
      g.save(); g.translate(720, 470); g.rotate(-0.18); g.scale(1.8 - 0.8 * k, 1.8 - 0.8 * k);
      g.strokeStyle = sc.stampColor || '#e5484d'; g.lineWidth = 10; g.font = `900 78px ${SANS}`;
      const sw = g.measureText(sc.stamp).width; rr(g, -sw / 2 - 30, -70, sw + 60, 110, 18); g.stroke();
      g.fillStyle = sc.stampColor || '#e5484d'; g.fillText(sc.stamp, -sw / 2, 12); g.restore();
    }
  } else {
    const rg = g.createRadialGradient(512, 340, 20, 512, 340, 420); rg.addColorStop(0, 'rgba(120,170,255,0.25)'); rg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = rg; g.fillRect(0, 0, w, h);
  }
  ROOM.stex.needsUpdate = true;
}

// ---------- shots: camera position, target and lens for each framing
const SHOTS = {
  wide: { p: V3(0.7, 2.6, 21.5), t: V3(-0.2, 1.5, 1.0), f: 30 },
  guy: { p: V3(0.4, 2.45, 10.6), t: V3(0.0, 2.25, 0.4), f: 26 },
  screen: { p: V3(3.55, 1.6, 10.6), t: V3(-1.82, 1.3, 2.25), f: 27 },
  bot: { p: V3(2.75, 1.9, 8.2), t: V3(2.0, 1.6, 1.7), f: 26 },
  desk: { p: V3(-0.6, 3.2, 14.0), t: V3(-0.4, 1.0, 1.4), f: 30 },
};
const LOOK = { screen: () => V3(-1.82, 0.4, 2.25), bot: () => BOT.root.position.clone().add(V3(0, 0.6, 0)), down: () => V3(0.05, -1.0, 1.6), cam: () => camera.position.clone() };
const FACES = {
  neutral: { bu: 0.6, bl: -0.78, brow: 0, browTilt: 0, o: 0, w: 1, blush: 0 },
  grin: { bu: 0.5, bl: -0.62, brow: 0.03, browTilt: 0, o: 0.24, w: 1.14, blush: 0.1 },
  happy: { bu: 0.44, bl: 0.44, brow: 0.06, browTilt: 0, o: 0.3, w: 1.14, blush: 0.42 },
  shock: { bu: 0.9, bl: -1.0, brow: 0.09, browTilt: 0, o: 0.95, w: 0.68, blush: 0 },
  meh: { bu: 0.24, bl: -0.42, brow: -0.03, browTilt: 0.26, o: 0.05, w: 0.9, blush: 0 },
  talk: { bu: 0.6, bl: -0.76, brow: 0.02, browTilt: 0, o: 0.3, w: 1, blush: 0, talk: 1 },
  sleep: { bu: -0.08, bl: -0.04, brow: -0.02, browTilt: 0, o: 0.06, w: 0.8, blush: 0 },
};
const lerpFace = (a, b, k) => { const o = {}; for (const key of Object.keys(a)) o[key] = mix(a[key] || 0, b[key] || 0, k); return o; };

// every character material, for the wireframe "built from shapes" effect
const CHAR_MATS = new Set();
rig.traverse((o) => { if (o.material) CHAR_MATS.add(o.material); });
const MAT0 = new Map([...CHAR_MATS].map((m) => [m, { e: m.emissive ? m.emissive.clone() : null, ei: m.emissiveIntensity }]));

function sceneAt(t) { let i = 0; while (i + 1 < SCENES.length && SCENES[i + 1].t0 <= t) i++; return i; }
function shotOf(s) { return SHOTS[s.shot] || SHOTS.wide; }

const camPos = V3(0, 0, 0), camTgt = V3(0, 0, 0);
function renderAt(time) {
  const t = clamp(time, 0, T);
  const i = sceneAt(t), S = SCENES[i], P0 = SCENES[Math.max(0, i - 1)];
  const u = t - S.t0;

  // camera: glide from the previous framing, then a slow push in
  const A = shotOf(P0), B = shotOf(S), k = i === 0 ? 1 : sstep(0, 0.7, u);
  const push = 1 - 0.035 * clamp(u / Math.max(0.5, S.t1 - S.t0));
  camPos.lerpVectors(A.p, B.p, k); camTgt.lerpVectors(A.t, B.t, k);
  camPos.sub(camTgt).multiplyScalar(push).add(camTgt);
  camPos.x += 0.06 * Math.sin(t * 0.7); camPos.y += 0.04 * Math.sin(t * 0.53);
  camera.fov = mix(A.f, B.f, k); camera.updateProjectionMatrix();
  camera.position.copy(camPos); camera.lookAt(camTgt);

  // robot: hidden until a scene pops it in, then bobs, waves, spins or gives a thumbs up
  const first = SCENES.findIndex((s) => s.bot && s.bot.act && s.bot.act !== 'hidden');
  const botOn = first >= 0 && i >= first && !(S.bot && S.bot.act === 'hidden');
  let sc = 0;
  if (botOn) { const tp = SCENES[first].t0 + (SCENES[first].bot.at || 0.3); sc = backOut((t - tp) / 0.45, 1.8); }
  BOT.root.scale.setScalar(Math.max(0.0001, sc));
  const act = (S.bot && S.bot.act) || 'idle';
  BOT.root.position.set(2.0, 0.95 + 0.08 * Math.sin(2 * Math.PI * t / 1.6), 1.7);
  BOT.body.rotation.z = 0.06 * Math.sin(2 * Math.PI * t / 2.3);
  const lookGuy = S.bot && S.bot.look === 'guy';
  BOT.body.rotation.y = mix(-0.08, -0.85, lookGuy ? 1 : 0) + (act === 'spin' ? 2 * Math.PI * sstep(0, 0.8, u) : 0);
  BOT.armR.rotation.z = act === 'wave' ? 2.3 + 0.45 * Math.sin(u * 13) : act === 'thumb' ? 2.7 : 0.15;
  BOT.armL.rotation.z = act === 'cheer' ? -2.6 + 0.2 * Math.sin(u * 11) : -0.15;
  const botHappy = ['thumb', 'spin', 'cheer'].includes(act);
  const bb = (t % 3.1) < 0.12 ? 0.1 : 1;
  BOT.eyeL.visible = BOT.eyeR.visible = !botHappy; BOT.happyL.visible = BOT.happyR.visible = botHappy;
  BOT.eyeL.scale.y = BOT.eyeR.scale.y = act === 'talk' ? 0.6 + 0.5 * Math.abs(Math.sin(u * 14)) : bb;
  BOT.ball.scale.setScalar(1 + 0.25 * Math.max(0, Math.sin(t * 5)));
  BOT.ring.scale.setScalar(1 + 0.08 * Math.sin(t * 9));

  // the guy: arms blend from the last scene's pose, head turns to what he looks at, face blends
  const G = S.guy || {}, G0 = P0.guy || {};
  const ka = i === 0 ? 1 : backOut(u / 0.35, 1.2);
  for (const side of ['r', 'l']) {
    const pk = side === 'r' ? 'pose' : 'poseL';
    const from = POSES[G0[pk] || (side === 'l' ? (G0.pose === 'cheer' ? 'cheer' : 'type') : 'type')] || POSES.type;
    const toName = G[pk] || (side === 'l' ? (G.pose === 'cheer' ? 'cheer' : 'type') : 'type');
    const to = POSES[toName] || POSES.type;
    const extra = { sh: 0, wz: 0, wx: 0, curl: 0 };
    if (toName === 'type') extra.wx = 0.14 * Math.sin(t * 15 + (side === 'r' ? 0 : 1.7));
    if (toName === 'open' || toName === 'cheer') extra.wz = 0.32 * Math.sin(u * 12);
    applyPose(arms[side], lerpPose(from, to, ka), extra);
  }
  const br = Math.sin(2 * Math.PI * t / 3.6);
  torso.scale.y = 1 + 0.01 * br; headPivot.position.y = 0.55 + 0.01 * br;
  let hop = 0;
  if (G.hop) { const hu = (u - (G.hopAt || 0.1)) / 0.6; if (hu >= 0 && hu <= 1) hop = kf([0, 0.3, 0, 0.1, 0], hu); }
  rig.position.y = hop;
  scene.updateMatrixWorld(true);
  const lookName = G.look || 'cam', look0 = G0.look || 'cam';
  const tgtA = (LOOK[look0] || LOOK.cam)(), tgtB = (LOOK[lookName] || LOOK.cam)();
  const kl = i === 0 ? 1 : sstep(0, 0.3, u);
  const tgt = tgtA.lerp(tgtB, kl);
  const hp = new THREE.Vector3(); headPivot.getWorldPosition(hp); hp.y += 0.95;
  const d = tgt.clone().sub(hp);
  const yaw = clamp(Math.atan2(d.x, d.z), -0.75, 0.75), pitch = clamp(-Math.atan2(d.y, Math.hypot(d.x, d.z)), -0.3, 0.35);
  const nod = G.nod ? 0.1 * Math.sin(Math.PI * clamp((u - 0.2) / 0.5)) : 0;
  headPivot.rotation.set(pitch * 0.7 + nod, yaw * 0.75 + 0.05 * Math.sin(t * 0.8), 0.035 * Math.sin(2 * Math.PI * t / 4.4));
  scene.updateMatrixWorld(true);
  let F = lerpFace(FACES[G0.face] || FACES.neutral, FACES[G.face] || FACES.neutral, i === 0 ? 1 : sstep(0, 0.22, u));
  if (G.face2 && u > (G.face2At || 1)) F = lerpFace(FACES[G.face] || FACES.neutral, FACES[G.face2] || FACES.neutral, sstep(0, 0.22, u - (G.face2At || 1)));
  const blink = ((t + 0.7) % 3.4) < 0.15 ? Math.sin(Math.PI * ((t + 0.7) % 3.4) / 0.15) : 0;
  for (const E of eyes) {
    const local = E.g.worldToLocal(tgt.clone());
    E.ball.rotation.set(clamp(-Math.atan2(local.y, Math.hypot(local.x, local.z)), -0.5, 0.5), clamp(Math.atan2(local.x, local.z), -0.55, 0.55), 0);
    const bk = blink * (F.bl > 0.2 ? 0 : 1);
    E.up.rotation.x = -mix(F.bu, -0.06, bk); E.lo.rotation.x = -mix(F.bl, -0.06, bk);
  }
  for (const Bw of brows) { Bw.holder.position.y = Bw.y0 + F.brow; Bw.b.rotation.z = Math.PI / 2 - 0.12 * Bw.s + F.browTilt * Bw.s; }
  M.blush.opacity = F.blush;
  let o = F.o, w = F.w;
  if (F.talk > 0.5) { o = 0.12 + 0.42 * Math.abs(Math.sin(u * 9.5)) * (0.6 + 0.4 * Math.sin(u * 3.3)); w = 0.9 + 0.15 * Math.sin(u * 7); }
  const ry = 0.016 + 0.13 * o, rx = 0.17 * w;
  cav.scale.set(rx, ry, 0.05);
  lipM.scale.set(rx + 0.042, ry + 0.042, 0.045); lipM.position.z = -0.014;
  const tv = sstep(0.06, 0.3, o);
  teeth.scale.set(0.035 * tv + 0.0001, rx * 0.72, 0.03); teeth.position.set(0, ry * 0.6, 0.032);
  const gv = sstep(0.3, 0.7, o);
  tongue.scale.set(0.085 * w, 0.04 * gv + 0.0001, 0.03); tongue.position.set(0, -ry * 0.5, 0.034);

  // wireframe flash: the character drawn as its shapes, then filled back in
  const wire = S.fx === 'wire' ? pulse(t, S.t0 + (S.fxAt || 0.4), 0.05, S.fxDur || 1.1, 0.05) : 0;
  for (const m of CHAR_MATS) {
    m.wireframe = wire > 0.5;
    if (m.emissive) { const z = MAT0.get(m); if (wire > 0.5) { m.emissive.setHex(0x3ad7ff); m.emissiveIntensity = 1.1; } else { m.emissive.copy(z.e); m.emissiveIntensity = z.ei; } }
  }
  hemi.intensity = wire > 0.5 ? 0.25 : 0.7;

  drawScreen(S.screen, u, i);
  glow.intensity = S.screen && S.screen.type !== 'blank' ? 9 : 5;
  renderer.render(scene, camera);
}

window.__p3d = { renderAt, scene, camera, renderer, POSES, SHOTS };
window.addEventListener('hf-seek', (e) => renderAt(e.detail.time));
renderAt(window.__hfThreeTime || 0);
if (document.fonts && document.fonts.ready) document.fonts.ready.then(() => { lastKey = ''; renderAt(window.__hfThreeTime || 0); });
