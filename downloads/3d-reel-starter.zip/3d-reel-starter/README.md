# 3D reel starter

A 3D presenter, a robot sidekick and a desk scene in Three.js. Write a reel as a short JSON file and render it with the free HyperFrames tool. No paid apps, no voiceover, no 3D modelling.

## Needs

- Python 3 with `numpy`, `soundfile` and `pillow` (`pip install numpy soundfile pillow`)
- Node 18+ (for HyperFrames and to fetch Three.js and GSAP)
- ffmpeg if you want to grab check frames

## Go

    python3 make.py examples/01_made_with_claude.json
    ./render.sh out/skit_01_made_with_claude

Open `out/skit_01_made_with_claude/master.mp4`. To change the story, copy an example and edit the scenes. SKILL.md lists every field.

## What's in here

- `skit3d.js`: the whole 3D scene (presenter, robot, room, camera shots, poses, faces, the monitor screens).
- `make.py`: turns the JSON into a HyperFrames project with headline text, a comment ending and a generated music track.
- `examples/`: two reels to copy, one with a different hoodie colour.
- `fonts/`: Montserrat, Archivo and JetBrains Mono under the SIL Open Font License (OFL.txt).

Three.js (MIT) and GSAP are downloaded from npm the first time you run `make.py`.
