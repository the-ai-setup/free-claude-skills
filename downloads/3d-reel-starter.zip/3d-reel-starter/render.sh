#!/bin/bash
# usage: ./render.sh out/skit_01_made_with_claude   -> out/skit_01_made_with_claude/master.mp4
# Needs Node 18+. If HyperFrames can't find Chrome, set HYPERFRAMES_BROWSER_PATH to a Chrome or chrome-headless-shell binary.
for d in "$@"; do
  ( cd "$d" && npx -y hyperframes@0.8.216 render . -o master.mp4 --quality looks --workers 2 )
done
