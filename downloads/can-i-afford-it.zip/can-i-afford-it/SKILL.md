---
name: can-i-afford-it
description: Check whether the user can afford a purchase before they buy it, using their own numbers: what's safe to spend until payday, what the purchase costs in hours of work, and when it would fit if it doesn't now. Use when the user asks "can I afford", "should I buy" or "is it worth it", or shares something they're about to buy.
---

# Can I afford it?

A calm check before money leaves the account. You do the maths; the user decides. This is a budgeting check, not financial advice.

## What you need

Ask once, in one message, for anything missing:

- The price.
- The money in their account now.
- Bills and fixed costs still to come out before payday, and the payday date.
- Their take-home pay per hour, or their monthly take-home and the hours they work.
- Optional: a savings goal they're working towards.

## Steps

1. Safe to spend = money now - bills still to come - a buffer (10% of what's left or £50, whichever is bigger).
2. Work out the days to payday, and what's safe to spend per day before and after the purchase.
3. Hours of work = price / take-home per hour, to the nearest half hour.
4. If the purchase takes safe-to-spend below zero, or below £10 a day until payday, it doesn't fit. Say so plainly and give one way it could: buy after payday, a cheaper or second-hand version, or put aside a set amount each week until it's covered.
5. If they have a savings goal, say how much later it would land.

## Output

**Verdict:** Fits / Tight / Doesn't fit

- Safe to spend now: £X (£Y a day until payday on DATE)
- After buying: £X (£Y a day)
- This costs: N hours of work
- If it doesn't fit: one option, with the numbers

## Rules

- Use their numbers only. Never guess an income, a balance or a bill.
- No judgement about what they want to buy. Just the numbers.
- Never suggest loans, credit cards, overdrafts, buy-now-pay-later or investments.
- Say once that this is a budgeting check, not financial advice.
