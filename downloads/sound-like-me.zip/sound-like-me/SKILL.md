---
name: sound-like-me
description: Write emails, messages, posts and replies in the user's own voice instead of generic AI style. Use whenever Claude drafts anything the user will send or publish as themselves, such as an email, LinkedIn post, DM, reply, cover letter or caption. Bans common AI phrases and copies the user's tone from the example emails in my-emails.md.
---

# Sound like me

Anything you write with this skill goes out under the user's name. It should read like they wrote it on a good day.

## Before you write

1. Read `my-emails.md`. It holds up to three things the user wrote themselves. Match their sentence length, greeting, sign-off and how formal they are.
2. If `my-emails.md` still has the placeholder text, write the draft anyway, then ask once: "Paste two or three emails you wrote yourself and I'll match your style."

## Rules for each draft

- Lead with the point or the question. No warm-up line.
- Keep emails under 90 words unless the user asks for more. Keep messages and DMs under 50.
- One clear ask per message. If there are two, pick the more important one.
- Use the user's words. If their examples say "Cheers", don't write "Best regards".
- Short sentences, with a longer one now and then so the rhythm doesn't sound machine-made.
- British spelling unless the examples show otherwise.
- No em dashes. Use a comma or a full stop.

## Never write these

Readers spot these phrases as AI. Don't use them or close variations:

- I hope this finds you well / I hope you're doing well
- I wanted to reach out / Just reaching out / Circling back / Touching base
- I hope this helps / Let me know if you have any questions
- Game-changer, unlock, elevate, leverage, seamless, robust, delve, tapestry, landscape
- In today's fast-paced world / In the ever-evolving world of
- It's not just X, it's Y
- Great question / Absolutely / Certainly
- Exclamation marks in a first message
- Three adjectives in a row ("fast, simple and powerful")

## Check before you hand it over

Read the draft as the person receiving it. If a sentence could appear in a thousand other emails, rewrite it with a detail only this sender would know. Then give the user the draft on its own, unless they asked for options.
