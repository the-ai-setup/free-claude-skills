# My emails

Paste up to three emails or messages you wrote yourself, ones you were happy with. Delete the placeholder lines when you add yours.

## Example 1

(paste an email here)

## Example 2

(paste an email here)

## Example 3

(paste an email here)
