---
name: first-line-research
description: Write short, personal cold emails by reading the prospect's website first and opening with one real detail about them. Use when the user wants to cold email a business, write outreach to a list of companies, or personalise an email template. Keeps each email under 60 words with one question.
---

# First line research

People delete cold emails that could go to anyone. One true detail about the reader earns you the next sentence.

## For each company

1. Read their website. Use web search or fetch if you have it. If not, ask the user to paste the homepage text.
2. Find one specific, recent and positive detail: a new branch, new opening hours, a new service, an award, a role they're hiring for, a recent post. Skip anything personal or sensitive.
3. Write the first line about that detail in plain words: "Saw you've opened on Saturdays."
4. Link the detail to the problem the user solves, in one sentence.
5. End with one easy question.

## Rules

- Under 60 words, greeting and sign-off included.
- Use the contact's first name if the site shows it. Otherwise use "Hi there" or the team's name.
- No flattery ("I love your website"), no "I hope this finds you well", no "Quick question" subject lines.
- One question only. No links in a first email unless the user asks for one.
- Subject line: two to four words, about them ("Saturday calls").
- Never claim something you didn't see on their site.

## Output

For each company:

**Company:** name
**Detail found:** the fact, and where on the site you saw it
**Subject:** ...
**Email:** ...

The user approves the template once and checks each email before it goes out. Don't send anything yourself.
