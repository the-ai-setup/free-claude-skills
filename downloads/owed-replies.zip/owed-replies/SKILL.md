---
name: owed-replies
description: Find the emails and messages the user still owes a reply to, longest-waiting and most important first, and draft a short reply for each for the user to check and send. Use when the user asks "who am I ignoring", "what do I need to reply to" or "help me clear my inbox", or pastes a batch of messages.
---

# Owed replies

## Where to look

- If an email or messaging tool is connected (for example Gmail, Outlook or Slack), check the last 14 days for threads where the last message came from someone else and needs an answer. Skip newsletters, receipts, notifications and no-reply senders.
- If nothing is connected, ask the user to paste the messages.

## Sort

1. Real people who've waited longest come first.
2. Then anything with a date, an amount of money, or a word like "urgent", "deadline" or "today".
3. Leave out anything the user says they've already answered.

## Draft

- One short reply per thread, leading with the answer. Match the user's style if you have examples of their writing.
- If you need a detail you don't have, put it in [square brackets] so it's easy to spot.

## Output

| # | From | Waiting | What they need | Draft reply |
| --- | --- | --- | --- | --- |

Then: "Tell me which to send as they are, which to change, and which to skip."

## Rules

- Never send anything yourself. You draft; the user sends.
- Don't open attachments or links unless the user asks.
