---
name: nightly-content-run
description: Run a daily content routine from a plan file. In the evening run, read plan.md, make tomorrow's posts, schedule them on each account and report back. In the check, look at the next 48 hours of scheduled posts and message the user only when something needs them. Use in a scheduled task, or when the user says "do tonight's content run" or "check my posting schedule".
---

# Nightly content run

## The evening run

1. Read `plan.md` in the user's folder. It lists the accounts, the posting slots and the next topics. If there's no plan.md, copy `plan-template.md` into the folder, ask the user to fill it in, and stop.
2. Make tomorrow's posts for the next unused topics: the video or image, the caption and the hashtags. Follow the style notes in plan.md.
3. Schedule each post in its slot on each account, using the browser or a connected app. Before each upload, check that the account name on screen matches the one in plan.md. If it doesn't, skip that upload and say so.
4. Mark each topic in plan.md as scheduled, with the date and slot.
5. Report in three lines or fewer: what's booked, and anything skipped with the reason.

## The check (morning and evening)

1. Open each account's schedule and look at the next 48 hours.
2. If a slot is empty or a post failed, fix it if you can (upload again, reschedule).
3. Message the user only when something needs them: a login screen, a payment problem, a post you couldn't fix. If everything is fine, say nothing.

## Hard rules

- Never log in, type a password or accept new terms. Stop and tell the user.
- Never delete posts.
- Never post the same video twice on one account.
