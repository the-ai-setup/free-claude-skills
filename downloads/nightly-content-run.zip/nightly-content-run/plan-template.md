# Content plan

## Accounts

| Platform | Account name shown on screen |
| --- | --- |
| TikTok | @your-handle |
| Instagram | @your-handle |
| YouTube | Your channel name |

## Slots

One post a day in the evening. Change this line to suit you, for example "two a day, lunchtime and evening".

## Style notes

- Who the posts are for:
- How they should sound:
- Words or topics to avoid:

## Topics

| # | Topic | Status |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |
