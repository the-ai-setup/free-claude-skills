# The prompts

You need two scheduled tasks in the Claude desktop app, both with your content folder attached.

## Task 1: the evening run (once a day, in the evening)

Use the nightly-content-run skill. Do the evening run from plan.md in my content folder: make tomorrow's posts, schedule them, update plan.md, and tell me in three lines what's booked. If anything needs me, say exactly what.

## Task 2: the check (twice a day, morning and evening)

Use the nightly-content-run skill. Do the check for the next 48 hours. Only message me if something needs me.
