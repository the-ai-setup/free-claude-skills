---
name: claude-memory
description: Give Claude a memory that lasts between chats: one short about-me file with the user's goals, work, routine, preferences and current projects, which Claude reads before it helps and offers to update when something changes. Use when the user says Claude keeps forgetting things, says "remember this", wants to set up their profile, or starts a new project.
---

# Claude memory

A new chat starts from nothing unless Claude has something to read. This skill keeps one short file that fixes that.

## The file

`about-me.md` sits in this skill's folder. Its sections are: Who I am, Goals this year, Work and routine, Projects right now, How I like answers, People I mention, Never do, Updated.

## Before you help

1. Read `about-me.md` and use what's relevant. Don't repeat it back to the user.
2. If it still holds the placeholder text, ask these five questions in one message, then write the file from the answers:
   1. What do you do, and what does a normal week look like?
   2. What are your top three goals this year?
   3. Which projects are you working on right now?
   4. How do you like answers: short or detailed, and in what tone?
   5. Is there anything I should never do?

## Keeping it current

- When the user shares something that will still matter next month (a new job, a goal, a change of routine, a preference), offer the one line you'd add and where it goes. Add it only after they say yes.
- If you can write files (Claude Code, or Claude desktop with folder access), update `about-me.md` yourself. If you can't (Claude on the web), give them the updated file to save and upload again.
- Keep each section under 8 lines. Replace old facts instead of piling up new ones, and put today's date under Updated.

## Never store

Passwords, bank or card details, ID numbers, health details they haven't asked you to keep, or private details about other people.
