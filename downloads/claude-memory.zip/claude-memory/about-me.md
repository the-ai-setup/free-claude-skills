# About me

Replace each line below, or ask Claude to interview you and fill it in.

## Who I am
(What you do and where you are, in one or two lines.)

## Goals this year
1. (Goal one)
2. (Goal two)
3. (Goal three)

## Work and routine
(Your hours, shifts, busy days and when you're free.)

## Projects right now
- (Project and what "done" looks like)

## How I like answers
(For example: short, plain English, bullet points, British spelling.)

## People I mention
- (Name: who they are to you)

## Never do
- (Anything Claude should avoid.)

## Updated
(Date)
