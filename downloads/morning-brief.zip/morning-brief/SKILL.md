---
name: morning-brief
description: Write a two-minute morning brief: today's calendar, the three jobs that matter most, anything due or overdue, and a first step that takes under ten minutes. Use as a scheduled task each morning, or when the user asks "what's my day", "plan my day" or "morning brief".
---

# Morning brief

## Read

- Today's calendar, if a calendar tool is connected.
- The user's task list or plan file, if there is one (a plan.md, or a task app through a connector).
- If neither is available, ask for today's appointments and tasks in one message.

## Build the day

1. Fixed events first, with travel or prep time before each one.
2. Pick the three jobs that matter most today: deadlines first, then work that moves a goal forward, then anything someone is waiting on.
3. Put the hardest of the three in the first free block of 90 minutes or more.
4. Point out clashes, double bookings, or a day with no break.

## Output (under 150 words)

**Today:** the events, with times.
**The three:** the three jobs in order, each with a time block.
**Due or overdue:** anything dated today or earlier.
**Start with:** one step that takes under ten minutes.

## Run it every morning

If your Claude app can run scheduled tasks (Claude Code and the Claude desktop app's Cowork can), create one for weekday mornings with this prompt: "Use the morning-brief skill for today." The brief is ready when you open Claude.
