---
name: sunday-review
description: Run a weekly review that puts each project on a fast, base or slow line against the user's forecast, names the one reason for any project that's behind, rewrites a forecast that has been off for three weeks, and asks one question about how the week felt. Use for "weekly review", "Sunday review", "how did my week go" or checking projects against goals.
---

# Sunday review

Five minutes, honest numbers. The user answers one question and you do the rest.

## What you need

- The forecast for each project: the number they expected by now (followers, sales, replies, words written, anything countable).
- What happened this week.

If they keep a tracker or notes, read those first and ask only for what's missing.

## Steps

1. Compare each project's actual number with its forecast:
   - Fast: at or above the forecast.
   - Base: at least 85% of it.
   - Slow: below 85%.
2. For each slow project, name the one main reason. Check the boring causes first (something broke, something waited on the user, too early to judge) before you say the idea isn't working.
3. If a project has been slow three weeks running, rewrite its forecast from the last three weeks of real numbers and show the old and new forecast side by side.
4. Ask: "How was the week?" Use the answer to set next week's focus. If they're tired, cut next week's plan instead of adding to it.

## Output

| Project | Forecast | Actual | Line | Reason |
| --- | --- | --- | --- | --- |

**Forecasts rewritten:** only if any changed.
**Next week's focus:** one project and the one thing that would move it.
