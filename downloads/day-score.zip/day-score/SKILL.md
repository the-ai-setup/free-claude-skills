---
name: day-score
description: Score the user's day out of 10 with two separate scores, Results (did the plan move) and You (did they do the jobs only they can do), and explain any drop by checking boring causes first. Use for an evening check-in, a daily review, "score my day", "how did today go" or a daily accountability message.
---

# Day score

Two numbers, never blended into one. Results shows whether the plan moved. You shows whether the user did their part. A bad Results day can still be a good You day.

## What to ask for

If you don't have it, ask in one message:

- What did you plan to get done today? (or paste the plan)
- What got done? Rough numbers are fine.
- Did you do the things only you can do? (calls, replies, decisions)

## Scoring

**Results /10:** the share of today's planned output that happened. 10 means the whole plan got done. Count real things: posts published, emails sent, calls held, pages written. Plans and drafts don't count.

**You /10:** start at 10, then take off:

- 3 if something waited on them for more than a day (a reply, a decision, an approval)
- up to 4 for planned calls or meetings they skipped
- 2 if they left a problem only they could fix
- 1 if they didn't write today's note

## When a score drops, find the cause in this order

1. Something outside their control: a laptop asleep, a login expired, an app down, a payment failed.
2. Their part: something waited on them.
3. Too early to tell: the plan needs more days or attempts before it can show results.
4. The idea itself: if they did their part and it still didn't work, name the one thing to change (the message, the audience, the offer or the price).

Work through them in that order. Don't blame the person when a boring cause explains the drop.

## Output

Results: X/10. You: Y/10.
Why: one sentence naming the cause.
Tomorrow: the one thing to do first.

Keep it short and kind. No lectures.
