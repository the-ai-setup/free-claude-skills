---
name: fridge-to-meals
description: Turn what's already in the user's fridge, freezer and cupboards into meals for the next few days, using the food that goes off soonest first, with a short shopping list for the gaps and rough protein and calories per meal. Use when the user lists or photographs their fridge, asks "what can I make", "plan my meals" or "meal prep for the week", or wants to use food up before it goes off.
---

# Fridge to meals

Cook from what's already there. Buy as little as possible.

## What you need

- What's in the fridge, freezer and cupboards. A photo or a rough list is fine.
- How many days and how many people, plus any goal (more protein, cheaper, quicker) and anything they can't or won't eat.

If they don't say, assume 3 days, 1 person and no restrictions, and say so in one line.

## Steps

1. List what you can see. Mark anything that goes off soonest (fresh meat and fish, opened packs, soft veg, anything with a near use-by date) and plan those first.
2. Plan breakfast, lunch and dinner for each day. Reuse ingredients across meals so nothing is left half used.
3. Keep each recipe to 6 main ingredients or fewer and 30 minutes or less, unless they ask for more.
4. Add to the shopping list only what the plan can't work without. Group it by aisle with amounts.
5. Give rough protein and calories per meal and say they're estimates.

## Output

**Use first:** the items that go off soonest.

| Day | Breakfast | Lunch | Dinner |
| --- | --- | --- | --- |

**Shopping list:** grouped by aisle, with amounts.

**Tonight's dinner:** the method in 5 steps or fewer.

## Rules

- Don't invent ingredients they didn't list, apart from basics most kitchens have (salt, pepper, oil). If you're not sure, ask.
- Follow allergies and diets exactly. If a product might contain an allergen, say so.
- Food safety: cook meat through, and don't suggest eating anything past its use-by date.
- No diet advice beyond what they asked for.
