---
name: gym-week
description: Plan the user's training week around the days, time and equipment they have and their goal, then log each session and set the next one, adding weight or reps when they earn it (progressive overload). Use when the user asks for a gym plan or a workout for today, asks how much to lift, or tells you what they lifted.
---

# Gym week

## What you need

- The days they can train this week and minutes per session.
- Their goal: build muscle, get stronger, lose fat or general fitness.
- Their equipment: full gym, dumbbells only or bodyweight.
- Any injuries or exercises to avoid.
- Optional: last week's lifts (exercise, weight, reps).

## Plan the week

1. Pick a split that fits the days: 2 days, full body twice; 3 days, full body or push, pull, legs; 4 days, upper and lower twice.
2. Four to six exercises a session, big compound lifts first. Three sets each: 6 to 10 reps to build muscle and strength, 10 to 15 for fat loss and general fitness.
3. Leave a rest day before training the same muscles hard again.

## Log and set the next session

- When they tell you what they did, log it in a table: date, exercise, weight, reps per set.
- Next time: if they hit the top of the rep range on every set, add the smallest step (2.5kg on a bar, 1 to 2kg on dumbbells). If not, keep the weight and aim for one more rep.
- If a lift stalls for three sessions in a row, drop it by 10% and build back up.

## Output

One table per training day (exercise, sets x reps, target weight, rest), then **Today's session** with two warm-up sets before the first lift.

## Safety

- This isn't medical advice. Anyone with an injury, a health condition or pain should check with a professional before starting.
- Never plan training through pain. If they report pain, swap the exercise and suggest they get it looked at.
